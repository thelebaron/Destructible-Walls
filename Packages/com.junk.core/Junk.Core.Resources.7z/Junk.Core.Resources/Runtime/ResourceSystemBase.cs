﻿using System;
using Unity.Assertions;
using Unity.Collections;
using Unity.Entities;

namespace Junk.Core.Resources
{
    /// <summary>
    /// Singleton Entity containing all resources
    /// </summary>
    public struct PrefabResources : IComponentData
    {

    }

    /// <summary>
    /// A resource aspect contains a lookup table for prefab data that can be used inside of jobs
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public struct PrefabReader<T>  where T : unmanaged, IEntityPrefab
    {
        private readonly   Entity                                     m_ResourceEntity;
        [ReadOnly] private ComponentDataFromEntity<EntityResource<T>> m_ComponentData;
        [ReadOnly] private BufferFromEntity<PrefabBuffer>             m_PrefabBuffer;
        [ReadOnly] private BufferFromEntity<PrefabIdBuffer>           m_PrefabIdBuffer;
        
        public Entity Prefab => m_ComponentData[m_ResourceEntity].Value.Prefab;

        public Entity PrefabById(string id)
        {
            var buffer   = m_PrefabBuffer[m_ResourceEntity];
            var idbuffer = m_PrefabIdBuffer[m_ResourceEntity];

            var array   = buffer.AsNativeArray();
            var idArray = idbuffer.AsNativeArray().Reinterpret<FixedString128Bytes>();
            
            Assert.IsTrue(idArray.Contains(id));
            
            if(idArray.Contains(id))
                return array[idArray.IndexOf(id)];
            
            throw new ArgumentException($"Prefab with id {id} not found");
        }
        
        public PrefabReader(Entity mResourceEntity, ComponentDataFromEntity<EntityResource<T>> mComponentData, BufferFromEntity<PrefabBuffer> mPrefabBuffer, BufferFromEntity<PrefabIdBuffer> mPrefabIdBuffer)
        {
            m_ResourceEntity = mResourceEntity;
            m_ComponentData = mComponentData;
            m_PrefabBuffer = mPrefabBuffer;
            m_PrefabIdBuffer = mPrefabIdBuffer;
        }
        
        
    }

    public abstract partial class ResourceSystemBase : SystemBase
    {
        /// <summary>
        /// Returns a lookup table for prefab data that can be used inside of jobs
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        protected PrefabReader<T> GetReader<T>() where T : unmanaged, IEntityPrefab
        {
            var resEntity   = GetSingletonEntity<PrefabResources>();
            var resData     = GetComponentDataFromEntity<EntityResource<T>>(true);
            var prefabBuf   = GetBufferFromEntity<PrefabBuffer>(true);
            var prefabIdBuf = GetBufferFromEntity<PrefabIdBuffer>(true);

            return new PrefabReader<T>(resEntity, resData, prefabBuf, prefabIdBuf);
        }
        
        /// <summary>
        /// testing
        /// </summary>
        private T TestAspect<T>() where T : unmanaged, IEntityPrefab
        {
            var singletonEntity = GetSingletonEntity<PrefabResources>();
            var data   = GetComponentDataFromEntity<EntityResource<T>>(true);
            
            return data[singletonEntity].Value;
        }
        
        protected override void OnCreate()
        {
            RequireSingletonForUpdate<PrefabResources>();
        }

        protected override void OnUpdate()
        {
            
        }
    }
    
    public class ResourceSystem : ResourceSystemBase
    {

    }
}