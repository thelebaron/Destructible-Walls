﻿using UnityEngine;
using Junk.Core.Resources;

namespace Junk.Core.Resources
{
    public class ResourceComponent : MonoBehaviour
    {
        public PrefabAssetRegistryBase PrefabAssetRegistry;
    }
}