﻿using System;
using Unity.Collections;
using Unity.Entities;
using UnityEngine;
using UnityEngine.Serialization;

namespace Junk.Core.Resources
{
    [Serializable]
    public class PrefabData<T> where T : unmanaged, IEntityPrefab
    {
        public                                GameObject Prefab;
        [FormerlySerializedAs("Name")] public string     Id;
    }
    
    public struct EntityResource<T> : IComponentData where T : unmanaged, IEntityPrefab
    {
        public FixedString128Bytes Id;
        public T              Value;
    
        // Implicit conversion from T to ResourceType<T>
        public static implicit operator EntityResource<T>(T value)
        {
            return new EntityResource<T>() { Value = value };
        }
    
        // Implicit conversion from ResourceType<T> to T
        public static implicit operator T(EntityResource<T> value)
        {
            return value.Value;
        }
    }
    
    public struct PrefabBuffer : IBufferElementData
    {
        public Entity         Prefab;
        public FixedString128Bytes Id;
        
        public static implicit operator PrefabBuffer(Entity prefab)
        {
            return new PrefabBuffer() { Prefab = prefab };
        }
        
        public static implicit operator Entity(PrefabBuffer prefab)
        {
            return prefab.Prefab;
        }
    }
    
    public struct PrefabIdBuffer : IBufferElementData
    {
        public FixedString128Bytes Id;
        
        // Implicit conversion from PrefabIdDatabase to PrefabBuffer
        public static implicit operator PrefabBuffer(PrefabIdBuffer value)
        {
            return new PrefabBuffer() { Id = value.Id };
        }
        
        // Implicit conversion from PrefabIdBuffer to FixedString128
        public static implicit operator FixedString128Bytes(PrefabIdBuffer value)
        {
            return value.Id;
        }
        // Implicit conversion from FixedString128 to PrefabIdBuffer
        public static implicit operator PrefabIdBuffer(FixedString128Bytes value)
        {
            return new PrefabIdBuffer() { Id = value };
        }
    }


    public interface IEntityPrefab
    {
        public Entity Prefab { get; set; }
    }


    
}


