﻿using Unity.Entities;
using UnityEngine;

namespace Junk.Core.Resources
{
    public class TestResourceAuthoring : MonoBehaviour, IConvertGameObjectToEntity
    {
        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            dstManager.AddComponentData(entity, new ForceTestResource());
        }
    }

    public struct ForceTestResource : IComponentData
    {
        public float Value;
    }
}