﻿using Unity.Entities;

namespace Junk.Core.Resources.Tests
{
    [DisableAutoCreation]
    public class TestResourceLoading : ResourceSystem
    {
        private EndSimulationEntityCommandBufferSystem endSimulationEcbSystem;
        private EntityQuery                    query;

        protected override void OnCreate()
        {
            base.OnCreate();
            query = GetEntityQuery(new EntityQueryDesc
            {
                All = new ComponentType[] {typeof(ForceTestResource)}
            });
            endSimulationEcbSystem = World.GetOrCreateSystem<EndSimulationEntityCommandBufferSystem>();
        }
        
        protected override void OnUpdate()
        {
            Dependency = new MyTestJob
            {
                AllPrefabsPrefabReader      = GetReader<AllPrefabs>(),
                //DummyPrefabReader           = GetReader<Dummy>(),
                ForceTestResourceTypeHandle = GetComponentTypeHandle<ForceTestResource>(),
                CommandBuffer               = endSimulationEcbSystem.CreateCommandBuffer().AsParallelWriter()
            }.ScheduleParallel(query, 1, Dependency);
            endSimulationEcbSystem.AddJobHandleForProducer(Dependency);
        }

        private struct MyTestJob : IJobEntityBatch
        {
            public PrefabReader<AllPrefabs>               AllPrefabsPrefabReader;
            //public PrefabReader<Dummy>                    DummyPrefabReader;
            public ComponentTypeHandle<ForceTestResource> ForceTestResourceTypeHandle;
            public EntityCommandBuffer.ParallelWriter     CommandBuffer;

            public void Execute(ArchetypeChunk batchInChunk, int batchIndex)
            {
                var prefab       = AllPrefabsPrefabReader.PrefabById("CanCrushed");
                var translations = batchInChunk.GetNativeArray(ForceTestResourceTypeHandle);
                for (int i = 0; i < batchInChunk.Count; i++)
                {
                    var translation = translations[i];
                    
                    //Resources resources = resourceAspect.ResData[resourceAspect.Entity];
                    //CommandBuffer.Instantiate(batchIndex, DummyPrefabReader.Prefab);
                    CommandBuffer.Instantiate(batchIndex, prefab);
                }
            }
        }
    }
}