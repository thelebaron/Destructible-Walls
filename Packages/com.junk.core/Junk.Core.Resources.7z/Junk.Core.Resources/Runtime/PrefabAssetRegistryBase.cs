﻿using Junk.Core.Resources;
using Unity.Entities;
using UnityEngine;

[assembly: RegisterGenericComponentType(typeof(EntityResource<AllPrefabs>))]

namespace Junk.Core.Resources
{
    public abstract class PrefabAssetRegistryBase : ScriptableObject
    {
        
    }
    
    /// <summary>
    /// This is a special prefab type that does not actually have a prefab, but is used to get the prefab buffer from the registry.
    /// </summary>
    public struct AllPrefabs : IEntityPrefab
    {
        [field: SerializeField] public Entity Prefab { get; set; }
    }
}