﻿using System;
using System.Reflection;
using Unity.Entities;
using Unity.Transforms;
using UnityEngine;

namespace Junk.Core.Resources
{
    [UpdateInGroup(typeof(GameObjectDeclareReferencedObjectsGroup))]
    public class DeclarePrefabResourceConversionSystem : BaseResourceConversionSystem
    {
        protected override void OnUpdate()
        {
            Entities.ForEach((ResourceComponent resourceComponent) =>
            {
                if(resourceComponent.PrefabAssetRegistry == null)
                    return;
                
                var ecsResourceData   = resourceComponent.PrefabAssetRegistry;

                foreach (var fieldInfo in ecsResourceData.GetType().GetFields())
                {
                    // Get the prefab from the fieldinfo
                    var gameObject = GetFieldValue<GameObject>(fieldInfo.GetValue(ecsResourceData), "Prefab");
                    if(gameObject!=null)
                        DeclareReferencedPrefab(gameObject); 
                }
            });
        }
    }
    
    public class ResourceConversionSystem : BaseResourceConversionSystem
    {
        protected override void OnUpdate()
        {
            Entities.ForEach((ResourceComponent resourceComponent) =>
            {
                if(resourceComponent.PrefabAssetRegistry == null)
                    return;
                
                DstEntityManager.AddComponentData(GetPrimaryEntity(resourceComponent), new PrefabResources());
                DstEntityManager.AddBuffer<PrefabBuffer>(GetPrimaryEntity(resourceComponent));
                DstEntityManager.AddBuffer<PrefabIdBuffer>(GetPrimaryEntity(resourceComponent));
                
                var resourceEntity  = GetPrimaryEntity(resourceComponent);
                var ecsResourceData = resourceComponent.PrefabAssetRegistry;
                
                // Add default prefab
                
                DstEntityManager.AddComponentData(resourceEntity, new EntityResource<AllPrefabs>
                {
                    Value = new AllPrefabs{ Prefab = Entity.Null }, Id = "AllPrefabs"
                });
                
                foreach (var fieldInfo in ecsResourceData.GetType().GetFields())
                {
                    //Debug.Log(IsSubclassOfRawGeneric(typeof(PrefabData<>), fieldInfo.GetValue(ecsResourceData).GetType()));
                    // Get the prefab from the fieldinfo
                    var go = GetFieldValue<GameObject>(fieldInfo.GetValue(ecsResourceData), "Prefab");
                    var id = GetFieldValue<string>(fieldInfo.GetValue(ecsResourceData), "Id");
                    
                    //calculate size of string
                    var size = sizeof(char) * id.Length;
                    if(size> 128)
                        throw new Exception($"Prefab Id {id} is too long. Max length is 128 bytes");
                    
                    if(go==null)  
                        continue;
                    
                    var entity = GetPrimaryEntity(go);

                    if (entity.Equals(Entity.Null))
                    {
                        Debug.LogError("Missing prefab in Entity Resources");
                        continue;
                    }

                    var datavalue = fieldInfo.GetValue(ecsResourceData);
                    if (fieldInfo.GetType().GetGenericArguments().Length < 1)
                    {
                        //Debug.Log(datavalue.GetType().Name); // PrefabData`1
                        //Debug.Log(datavalue.GetType().GenericTypeArguments[0]); //acunit
                        var typeArgument = datavalue.GetType().GenericTypeArguments[0];
                        
                        // See https://stackoverflow.com/questions/3788225/generic-class-type-gettype
                        Type    template    = typeof(EntityResource<>);
                        Type    genericType = template.MakeGenericType(typeArgument);
                        dynamic componentInstance    = Activator.CreateInstance(genericType);
                    
                        //var clone = Activator.CreateInstance(t, new object[] { GetPrimaryEntity((GameObject) fieldInfo.GetValue(resourceComponent.EcsResourceData)) });

                        componentInstance.Id = id;//fieldInfo.Name;
                        //instance.Value.Prefab = entity;
                        var defaultData = componentInstance.Value;
                        defaultData.Prefab = entity;
                        componentInstance.Value = defaultData;
                        
                        //Debug.Log("adding " + entity + " to resentity");
                        DstEntityManager.AddComponentData(resourceEntity, componentInstance);
                        
                        
                        var buffer = DstEntityManager.GetBuffer<PrefabBuffer>(GetPrimaryEntity(resourceComponent));
                        buffer.Add(new PrefabBuffer { Prefab = entity, Id = id });
                        var idBuffer = DstEntityManager.GetBuffer<PrefabIdBuffer>(GetPrimaryEntity(resourceComponent));
                        idBuffer.Add(new PrefabIdBuffer { Id = id });
                        continue;
                        
                    }
                    
                }
            });
        }
    }
    
    
    [UpdateInGroup(typeof(GameObjectAfterConversionGroup))]
    public class ResourceAfterConversionSystem : BaseResourceConversionSystem
    {
        protected override void OnUpdate()
        {
            Entities.ForEach((ResourceComponent resourceComponent) =>
            {
                if(resourceComponent.PrefabAssetRegistry == null)
                    return;

                var entity = GetPrimaryEntity(resourceComponent);
                
                // Remove unnecessary components
                if (DstEntityManager.HasComponent<Translation>(entity))
                    DstEntityManager.RemoveComponent<Translation>(entity);
                if (DstEntityManager.HasComponent<Rotation>(entity))
                    DstEntityManager.RemoveComponent<Rotation>(entity);
                if (DstEntityManager.HasComponent<LocalToWorld>(entity))
                    DstEntityManager.RemoveComponent<LocalToWorld>(entity);
                if (DstEntityManager.HasComponent<LocalToParent>(entity))
                    DstEntityManager.RemoveComponent<LocalToParent>(entity);
            });
        }
    }
    
    public abstract class BaseResourceConversionSystem : GameObjectConversionSystem
    {
        protected static T GetFieldValue<T>(object obj, string fieldName)
        {
            if (obj == null)
                throw new ArgumentNullException("obj");

            var field = obj.GetType().GetField(fieldName, BindingFlags.Public |
                                                          BindingFlags.NonPublic |
                                                          BindingFlags.Instance);

            if (field == null)
                throw new ArgumentException("fieldName", "No such field was found.");

            if (!typeof(T).IsAssignableFrom(field.FieldType))
                throw new InvalidOperationException("Field type and requested type are not compatible.");

            return (T)field.GetValue(obj);
        }
        
        protected static bool IsSubclassOfRawGeneric(Type generic, Type toCheck) 
        {
            while (toCheck != null && toCheck != typeof(object)) 
            {
                var cur = toCheck.IsGenericType ? toCheck.GetGenericTypeDefinition() : toCheck;
                if (generic == cur) 
                {
                    return true;
                }
                toCheck = toCheck.BaseType;
            }
            return false;
        }
    }
}
