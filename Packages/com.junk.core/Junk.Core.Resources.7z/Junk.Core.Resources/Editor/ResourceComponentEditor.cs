﻿using Junk.Core.Resources;
using UnityEditor;
using UnityEngine;

namespace Junk.Core.Resources.Editor
{
    [CustomEditor(typeof(ResourceComponent))]
    public class ResourceComponentEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            var t = target as ResourceComponent;

            if(t.PrefabAssetRegistry == null)
            {
                if (GetBaseInstances().Length > 1)
                {
                    Debug.Log("Multiple prefab asset registries found, using first one.");
                    t.PrefabAssetRegistry = GetBaseInstances()[0];
                }
                else if (GetBaseInstances().Length == 1)
                {
                    t.PrefabAssetRegistry = GetBaseInstances()[0];
                }
                else
                {
                    Debug.Log("No prefab asset registry found, please create one.");
                }
            }
            
            
        }

        private static PrefabAssetRegistryBase[] GetBaseInstances()
        {
            string[]                  guids = AssetDatabase.FindAssets("t:"+ typeof(PrefabAssetRegistryBase).Name);  //FindAssets uses tags check documentation for more info
            PrefabAssetRegistryBase[] a     = new PrefabAssetRegistryBase[guids.Length];
            for(int i =0;i<guids.Length;i++)         //probably could get optimized 
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                a[i] = AssetDatabase.LoadAssetAtPath<PrefabAssetRegistryBase>(path);
            }
 
            return a;
        }
        
        private static T[] GetAllInstances<T>() where T : ScriptableObject
        {
            string[] guids = AssetDatabase.FindAssets("t:"+ typeof(T).Name);  //FindAssets uses tags check documentation for more info
            T[]      a     = new T[guids.Length];
            for(int i =0;i<guids.Length;i++)         //probably could get optimized 
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                a[i] = AssetDatabase.LoadAssetAtPath<T>(path);
            }
 
            return a;
        }
    }
}