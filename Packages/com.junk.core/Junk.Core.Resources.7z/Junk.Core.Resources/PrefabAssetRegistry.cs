﻿using Junk.Core.Resources;
using Unity.Entities;
using UnityEngine;

[assembly: RegisterGenericComponentType(typeof(EntityResource<AcUnit>))]
[assembly: RegisterGenericComponentType(typeof(EntityResource<Bullet>))]
[assembly: RegisterGenericComponentType(typeof(EntityResource<BloodDecal>))]
[assembly: RegisterGenericComponentType(typeof(EntityResource<BulletDecal>))]
[assembly: RegisterGenericComponentType(typeof(EntityResource<BulletmarkLargeDecal>))]
[assembly: RegisterGenericComponentType(typeof(EntityResource<SmallDebris>))]

[CreateAssetMenu(menuName = "DOTS/Prefab Asset Registry")]
public class PrefabAssetRegistry : PrefabAssetRegistryBase
{
    public PrefabData<AcUnit>               AcUnit;
    public PrefabData<Bullet>               Bullet;
    public PrefabData<BloodDecal>           BloodDecal;
    public PrefabData<BulletDecal>          BulletDecal;
    public PrefabData<BulletmarkLargeDecal> BulletmarkLargeDecal;
    public PrefabData<SmallDebris>          SmallDebris;
}
    
public struct AcUnit : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; } 
}

public struct Bullet : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; }
}

public struct BloodDecal : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; }
}

public struct BulletDecal : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; }
}

public struct BulletmarkLargeDecal : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; }
}

public struct SmallDebris : IEntityPrefab
{
    [field: SerializeField] public Entity Prefab { get; set; }
}