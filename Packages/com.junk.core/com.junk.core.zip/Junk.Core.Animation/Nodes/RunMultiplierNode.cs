﻿using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;

namespace Junk.Core.Animation.Nodes
{
    public class RunMultiplierNode : KernelPassThroughNode<RunMultiplierNode, float, RunMultiplierNode.Kernel>
    {
        [BurstCompile /*(FloatMode = FloatMode.Fast)*/]
        public struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                context.Resolve(ref ports.Output) = context.Resolve(ports.Input) * 1.5f;
            }
        }
    }
}