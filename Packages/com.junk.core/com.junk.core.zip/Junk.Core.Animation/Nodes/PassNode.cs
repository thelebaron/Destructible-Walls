using Unity.DataFlowGraph;
using Debug = UnityEngine.Debug;

namespace Junk.Core.Animation
{
    public class PassNode : KernelNodeDefinition<PassNode.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<PassNode, float>  Input;
            public DataOutput<PassNode, float> Output;
        }

        struct KernelData : IKernelData
        {
            public int   SetTime;
            public float Time;
        }

        //[BurstCompile /*(FloatMode = FloatMode.Fast)*/]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                //var d = context.Resolve(ports.Input);
                var d = context.Resolve(ref ports.Output);
                Debug.Log(d);
                //context.Resolve(ref ports.Output) = context.Resolve(ports.Input);
            }
        }
    }
}