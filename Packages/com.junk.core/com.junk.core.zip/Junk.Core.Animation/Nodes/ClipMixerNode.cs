using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;

namespace Junk.Core.Animation
{
    public class ClipMixerNode : SimulationKernelNodeDefinition<ClipMixerNode.SimPorts, ClipMixerNode.KernelDefs>
    {
        const ushort k_ClipCount = 3;

        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<ClipMixerNode, ClipConfiguration> Configuration;
            public MessageInput<ClipMixerNode, Rig>               Rig;

            public MessageInput<ClipMixerNode, BlobAssetReference<Clip>> Clip0;
            public MessageInput<ClipMixerNode, BlobAssetReference<Clip>> Clip1;
            public MessageInput<ClipMixerNode, BlobAssetReference<Clip>> Clip2;

#pragma warning disable 0649
            internal MessageOutput<ClipMixerNode, Rig>                                 m_OutRig;
            internal MessageOutput<ClipMixerNode, ClipConfiguration>                   m_OutConfiguration;
            internal PortArray<MessageOutput<ClipMixerNode, BlobAssetReference<Clip>>> m_OutClips;
#pragma warning restore 0649
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ClipMixerNode, float> Time;
            public DataInput<ClipMixerNode, float> Time2; // just a shitty hack to set speed for third run clip
            public DataInput<ClipMixerNode, float> DeltaTime;
            public DataInput<ClipMixerNode, float> Weight;

            public DataOutput<ClipMixerNode, Buffer<AnimatedData>> Output;
        }

        struct Data
                : INodeData
                , IInit
                , IDestroy
                , IMsgHandler<Rig>
                , IMsgHandler<BlobAssetReference<Clip>>
                , IMsgHandler<ClipConfiguration>
        {
            NodeHandle<KernelPassThroughNodeFloat> m_TimeNode;
            NodeHandle<KernelPassThroughNodeFloat> m_RunTimeNode;
            NodeHandle<KernelPassThroughNodeFloat> m_DeltaTimeNode;
            NodeHandle<KernelPassThroughNodeFloat> m_WeightNode;

            NodeHandle<UberClipNode> m_Clip0;
            NodeHandle<UberClipNode> m_Clip1;
            NodeHandle<UberClipNode> m_Clip2;

            NodeHandle<NMixerNode>                 m_NMixerNode;
            NodeHandle<ClipMixerComputeWeightNode> m_ComputeWeightNode;

            public void Init(InitContext ctx)
            {
                var thisHandle = ctx.Set.CastHandle<ClipMixerNode>(ctx.Handle);

                m_TimeNode      = ctx.Set.Create<KernelPassThroughNodeFloat>();
                m_RunTimeNode      = ctx.Set.Create<KernelPassThroughNodeFloat>();
                
                m_DeltaTimeNode = ctx.Set.Create<KernelPassThroughNodeFloat>();
                m_WeightNode    = ctx.Set.Create<KernelPassThroughNodeFloat>();

                m_Clip0 = ctx.Set.Create<UberClipNode>();
                m_Clip1 = ctx.Set.Create<UberClipNode>();
                m_Clip2 = ctx.Set.Create<UberClipNode>();

                m_NMixerNode        = ctx.Set.Create<NMixerNode>();
                m_ComputeWeightNode = ctx.Set.Create<ClipMixerComputeWeightNode>();

                ctx.Set.Connect(m_TimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip0, UberClipNode.KernelPorts.Time);
                ctx.Set.Connect(m_TimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip1, UberClipNode.KernelPorts.Time);
                ctx.Set.Connect(m_RunTimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip2, UberClipNode.KernelPorts.Time);

                ctx.Set.Connect(m_DeltaTimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip0, UberClipNode.KernelPorts.DeltaTime);
                ctx.Set.Connect(m_DeltaTimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip1, UberClipNode.KernelPorts.DeltaTime);
                ctx.Set.Connect(m_DeltaTimeNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_Clip2, UberClipNode.KernelPorts.DeltaTime);

                ctx.Set.SetPortArraySize(m_NMixerNode, NMixerNode.KernelPorts.Inputs, k_ClipCount);
                ctx.Set.Connect(m_Clip0, UberClipNode.KernelPorts.Output, m_NMixerNode, NMixerNode.KernelPorts.Inputs, 0);
                ctx.Set.Connect(m_Clip1, UberClipNode.KernelPorts.Output, m_NMixerNode, NMixerNode.KernelPorts.Inputs, 1);
                ctx.Set.Connect(m_Clip2, UberClipNode.KernelPorts.Output, m_NMixerNode, NMixerNode.KernelPorts.Inputs, 2);

                ctx.Set.Connect(m_WeightNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_ComputeWeightNode, ClipMixerComputeWeightNode.KernelPorts.Input);
                ctx.Set.SetPortArraySize(m_NMixerNode, NMixerNode.KernelPorts.Weights, k_ClipCount);
                ctx.Set.Connect(m_ComputeWeightNode, ClipMixerComputeWeightNode.KernelPorts.OutWeight0, m_NMixerNode, NMixerNode.KernelPorts.Weights, 0);
                ctx.Set.Connect(m_ComputeWeightNode, ClipMixerComputeWeightNode.KernelPorts.OutWeight1, m_NMixerNode, NMixerNode.KernelPorts.Weights, 1);
                ctx.Set.Connect(m_ComputeWeightNode, ClipMixerComputeWeightNode.KernelPorts.OutWeight2, m_NMixerNode, NMixerNode.KernelPorts.Weights, 2);

                // Setup internal message connections
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, m_Clip0, UberClipNode.SimulationPorts.Rig);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, m_Clip1, UberClipNode.SimulationPorts.Rig);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, m_Clip2, UberClipNode.SimulationPorts.Rig);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, m_NMixerNode, NMixerNode.SimulationPorts.Rig);

                ctx.Set.SetPortArraySize(thisHandle, SimulationPorts.m_OutClips, k_ClipCount);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClips, 0, m_Clip0, UberClipNode.SimulationPorts.Clip);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClips, 1, m_Clip1, UberClipNode.SimulationPorts.Clip);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClips, 2, m_Clip2, UberClipNode.SimulationPorts.Clip);

                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutConfiguration, m_Clip0, UberClipNode.SimulationPorts.Configuration);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutConfiguration, m_Clip1, UberClipNode.SimulationPorts.Configuration);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutConfiguration, m_Clip2, UberClipNode.SimulationPorts.Configuration);

                // Setup port forwarding
                ctx.ForwardInput(KernelPorts.Time, m_TimeNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardInput(KernelPorts.Time2, m_RunTimeNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardInput(KernelPorts.DeltaTime, m_DeltaTimeNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardInput(KernelPorts.Weight, m_WeightNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardOutput(KernelPorts.Output, m_NMixerNode, NMixerNode.KernelPorts.Output);
            }

            public void Destroy(DestroyContext ctx)
            {
                ctx.Set.Destroy(m_TimeNode);
                ctx.Set.Destroy(m_DeltaTimeNode);
                ctx.Set.Destroy(m_WeightNode);

                ctx.Set.Destroy(m_Clip0);
                ctx.Set.Destroy(m_Clip1);
                ctx.Set.Destroy(m_Clip2);

                ctx.Set.Destroy(m_NMixerNode);
                ctx.Set.Destroy(m_ComputeWeightNode);
            }

            public void HandleMessage(MessageContext ctx, in Rig rig) =>
                ctx.EmitMessage(SimulationPorts.m_OutRig, rig);

            public void HandleMessage(MessageContext ctx, in BlobAssetReference<Clip> clip)
            {
                if (ctx.Port == SimulationPorts.Clip0)
                {
                    ctx.EmitMessage(SimulationPorts.m_OutClips, 0, clip);
                }
                else if (ctx.Port == SimulationPorts.Clip1)
                {
                    ctx.EmitMessage(SimulationPorts.m_OutClips, 1, clip);
                }
                else if (ctx.Port == SimulationPorts.Clip2)
                {
                    ctx.EmitMessage(SimulationPorts.m_OutClips, 2, clip);
                }
            }

            public void HandleMessage(MessageContext ctx, in ClipConfiguration clipConfiguration) =>
                ctx.EmitMessage(SimulationPorts.m_OutConfiguration, clipConfiguration);
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
            }
        }
    }

    public class ClipMixerComputeWeightNode : KernelNodeDefinition<ClipMixerComputeWeightNode.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ClipMixerComputeWeightNode, float> Input;

            public DataOutput<ClipMixerComputeWeightNode, float> OutWeight0;
            public DataOutput<ClipMixerComputeWeightNode, float> OutWeight1;
            public DataOutput<ClipMixerComputeWeightNode, float> OutWeight2;
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                ctx.Resolve(ref ports.OutWeight0) = 0f;
                ctx.Resolve(ref ports.OutWeight1) = 0f;
                ctx.Resolve(ref ports.OutWeight2) = 0f;

                // 0-1 clamp
                var w1 = math.modf(math.clamp(ctx.Resolve(ports.Input), 0f, 2f), out float index);
                var w0 = 1f - w1;

                //Debug.Log(ctx.Resolve(ports.Input));
                //Debug.Log(w0 + " - " + w1);
                //index = ctx.Resolve(ports.Input); // index always 0, maybe due to clamping or port input but temp workaround TOO JERKY
                if (index < 1f)
                {
                    ctx.Resolve(ref ports.OutWeight0) = w0;
                    ctx.Resolve(ref ports.OutWeight1) = w1;
                    //Debug.Log(w0 + " w0 - " + w1 +" w1");
                }
                else if (index < 2f)
                {
                    ctx.Resolve(ref ports.OutWeight1) = w0;
                    ctx.Resolve(ref ports.OutWeight2) = w1;
                    //Debug.Log(w0 + " w0 - " + w1 +" w1");
                }
                else
                {
                    ctx.Resolve(ref ports.OutWeight2) = 1; // Note max weight is 1
                }
            }
        }
    }
}