using Unity.Animation;
using Unity.Burst;
using Unity.Collections;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;
using Debug = UnityEngine.Debug;

namespace Junk.Core.Animation
{
    public struct NClipController : IComponentData
    {
        public bool  PlayClip;
        public int   ClipIndex;
        public bool  Loop;
        public float Duration;
        
        public FixedList128<EventState> Events;
    }

    public struct ClipData
    {
        public int                            ClipIndex;
        public BlobAssetReference<Clip>       Clip;
        public BlobAssetReference<ClipEvents> Events;
        public ClipConfiguration              Configuration;
        public float                          Duration;
        public bool                           LoopTime; // maybe rename blendback? blendout? transition?
        /*
         enclose in struct if this is redone ie BlendParams {
        public float                          BlendInWeight; // 0 - 1
        public float                          BlendInTime; // 0 - 1
        public float                          BlendOutWeight; // 0 - 1
        public float                          BlendOutTime; // 0 - 1
        }
        */
    }

    /// <summary>
    /// Mixes a single clip with another animation stream. This node is a workaround for the messaging system being incompatible with burst.
    /// </summary>
    public class PlayNClipNode : SimulationKernelNodeDefinition<PlayNClipNode.SimPorts, PlayNClipNode.KernelDefs>, IRigContextHandler<PlayNClipNode.Data>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public   MessageInput<PlayNClipNode, float>  Time; // This is used during gameplay to set the time of the animation clip to 0 to restart it.
            internal MessageOutput<PlayNClipNode, float> m_OutTime; // No specific message handler here as forwarded to time node in initialization.

            public MessageInput<PlayNClipNode, Rig>      Rig;
            public MessageInput<PlayNClipNode, int>      ClipCount;
            public MessageInput<PlayNClipNode, ClipData> ClipData;
            public MessageInput<PlayNClipNode, bool>     Init;
            
            // For internal messages in node data.
            internal MessageOutput<PlayNClipNode, Rig>                                 m_OutRig;
            internal PortArray<MessageOutput<PlayNClipNode, ClipConfiguration>>        m_OutClipConfigs;
            internal PortArray<MessageOutput<PlayNClipNode, BlobAssetReference<Clip>>> m_OutClips;
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<PlayNClipNode, Buffer<AnimatedData>>  InputStream; // takes an animation stream(usually the movement mixer node)
            public DataInput<PlayNClipNode, NClipController>       Controller;
            public DataInput<PlayNClipNode, float>                 DeltaTime;
            public DataInput<PlayNClipNode, float>                 Speed; //Gets forwarded to the time counter node parameter for clip playback speed
            public DataInput<PlayNClipNode, TimingController>      TimeControl;

            internal DataInput<PlayNClipNode, Buffer<AnimatedData>> NMixerStream; // nMixer output stream
            internal DataInput<PlayNClipNode, float>                InternalDeltaTime;
            internal DataOutput<PlayNClipNode, int>                 OutIndex; // index of the clip that is playing, gets passed to the NWeightNode.

            public DataOutput<PlayNClipNode, Buffer<AnimatedData>> Output;
            public DataOutput<PlayNClipNode, NClipController>      OutController;
            public DataOutput<PlayNClipNode, TimingController>     OutTimingController;
        }

        internal enum ClipBlendState
        {
            BlendIn, //Until the weight reaches 1, state is considered to be BlendIn.
            Playing, //When the weight reaches 1, state is considered to be Playing.
            BlendOut, //When the weight reaches 0, state is considered to be BlendOut.
        }
        
        /// <summary>
        /// Simulation Data
        /// </summary>
        [Managed] 
        struct Data : INodeData
            , IInit
            , IDestroy
            , IMsgHandler<Rig>
            , IMsgHandler<float>
            , IMsgHandler<int>
            , IMsgHandler<ClipData>
            , IMsgHandler<bool>
        {
            private KernelData                             kernelData;
            private NodeHandle<TimingNode>                 timeNode;
            private NodeHandle<KernelPassThroughNodeFloat> deltaPassNode;
            private NodeHandle<NWeight>                    nWeightNode;
            private NodeHandle<NMixerNode>                 mixerNode;
            private NodeHandle<UberClipNode>[]             clipMotionNodes;

            public void Init(InitContext ctx)
            {
                var thisHandle = ctx.Set.CastHandle<PlayNClipNode>(ctx.Handle);
                deltaPassNode   = ctx.Set.Create<KernelPassThroughNodeFloat>();
                timeNode        = ctx.Set.Create<TimingNode>();
                nWeightNode     = ctx.Set.Create<NWeight>();
                mixerNode       = ctx.Set.Create<NMixerNode>();
                //clipMotionNodes = new List<NodeHandle<UberClipNode>>();
                
                // Setup port connections
                ctx.Set.Connect(deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, timeNode, TimingNode.KernelPorts.DeltaTime);
                ctx.Set.Connect(deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, thisHandle, KernelPorts.InternalDeltaTime);
                ctx.Set.Connect(mixerNode, NMixerNode.KernelPorts.Output, thisHandle, KernelPorts.NMixerStream);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutTime, timeNode, TimingNode.SimulationPorts.Time);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, mixerNode, NMixerNode.SimulationPorts.Rig);
                ctx.Set.Connect(thisHandle, KernelPorts.OutIndex, nWeightNode, NWeight.KernelPorts.Input, NodeSetAPI.ConnectionType.Feedback);
                
                // Setup port forwarding
                ctx.ForwardInput(SimulationPorts.Time, timeNode, TimingNode.SimulationPorts.Time);
                ctx.ForwardInput(KernelPorts.DeltaTime, deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardInput(KernelPorts.Speed, timeNode, TimingNode.KernelPorts.Speed);
                ctx.ForwardInput(KernelPorts.TimeControl, timeNode, TimingNode.KernelPorts.TimingController);
                ctx.ForwardOutput(KernelPorts.OutTimingController, timeNode, TimingNode.KernelPorts.OutputTimingController);
            }

            public void Destroy(DestroyContext ctx)
            {
                ctx.Set.Destroy(timeNode);
                ctx.Set.Destroy(deltaPassNode);
                ctx.Set.Destroy(mixerNode);
                ctx.Set.Destroy(nWeightNode);
                
                for (int i = 0; i < clipMotionNodes.Length; i++)
                    ctx.Set.Destroy(clipMotionNodes[i]);
            }

            public void HandleMessage(MessageContext ctx, in Rig rig)
            {
                ctx.EmitMessage(SimulationPorts.m_OutRig, rig);
                kernelData.RigDefinition = rig;
                ctx.UpdateKernelData(kernelData);

                ctx.Set.SetBufferSize(ctx.Handle, (OutputPortID) KernelPorts.Output, Buffer<AnimatedData>.SizeRequest(rig.Value.IsCreated ? rig.Value.Value.Bindings.StreamSize : 0));
            }

            public void HandleMessage(MessageContext ctx, in float msg)
            {
                if (ctx.Port == SimulationPorts.Time)
                {
                    ctx.EmitMessage(SimulationPorts.m_OutTime, 0);
                }
            }
            
            /// <summary>
            /// Set all buffers to the correct size
            /// </summary>
            public void HandleMessage(MessageContext ctx, in int count)
            {
                if (ctx.Port != SimulationPorts.ClipCount)
                    return;
                
                kernelData.ClipDurationBuffer        = new FixedList4096<float>();
                kernelData.ClipDataBuffer            = new FixedList4096<ClipData>();
                kernelData.ClipDurationBuffer.Length = count;
                kernelData.ClipDataBuffer.Length     = count;
                ctx.UpdateKernelData(kernelData);
                
                var thisHandle = ctx.Set.CastHandle<PlayNClipNode>(ctx.Handle);
                ctx.Set.SetPortArraySize(thisHandle, SimulationPorts.m_OutClipConfigs, (ushort)count);
                ctx.Set.SetPortArraySize(thisHandle, SimulationPorts.m_OutClips, (ushort)count);
                ctx.Set.SetPortArraySize(nWeightNode, NWeight.KernelPorts.WeightsN, count);
                ctx.Set.SetPortArraySize(nWeightNode, NWeight.KernelPorts.OutputWeights, count);
                ctx.Set.SetPortArraySize(mixerNode, NMixerNode.KernelPorts.Inputs, count);
                ctx.Set.SetPortArraySize(mixerNode, NMixerNode.KernelPorts.Weights, count);
                
                clipMotionNodes = new NodeHandle<UberClipNode>[count];
            }
            
            public void HandleMessage(MessageContext ctx, in ClipData data)
            {
                if (ctx.Port == SimulationPorts.ClipData)
                {
                    var thisHandle = ctx.Set.CastHandle<PlayNClipNode>(ctx.Handle);
                    var index      = data.ClipIndex;
                    var clipNode   = ctx.Set.Create<UberClipNode>();
                    
                    //clipMotionNodes.Add(clipNode);
                    //kernelData.ClipDurationBuffer.Add(data.Duration);
                    //Debug.Log( "HandleMessage" + clipMotionNodes.Length);
                    clipMotionNodes[index] = clipNode;
                    kernelData.ClipDurationBuffer[index] = data.Duration;
                    kernelData.ClipDataBuffer[index] = data;
                    
                    ctx.UpdateKernelData(kernelData);

                    ctx.Set.Connect(timeNode, TimingNode.KernelPorts.Time, clipNode, UberClipNode.KernelPorts.Time);
                    ctx.Set.Connect(timeNode, TimingNode.KernelPorts.OutputDeltaTime, clipNode, UberClipNode.KernelPorts.DeltaTime);
                    ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, clipNode, UberClipNode.SimulationPorts.Rig);
                    ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClips, index, clipNode, UberClipNode.SimulationPorts.Clip);
                    ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClipConfigs, index, clipNode, UberClipNode.SimulationPorts.Configuration);

                    ctx.EmitMessage(SimulationPorts.m_OutClips, index, data.Clip);
                    ctx.EmitMessage(SimulationPorts.m_OutClipConfigs, index, data.Configuration);//new ClipConfiguration { Mask = ClipConfigurationMask.NormalizedTime });
                    //ctx.EmitMessage(SimulationPorts.m_OutRig, data.Rig);
                }
            }


            
            /// <summary>
            /// Finally connect mixer ports
            /// </summary>
            public void HandleMessage(MessageContext ctx, in bool initialize)
            {
                var thisHandle = ctx.Set.CastHandle<PlayNClipNode>(ctx.Handle);
                for (var i = 0; i < clipMotionNodes.Length; i++)
                {
                    ctx.Set.Connect(clipMotionNodes[i], UberClipNode.KernelPorts.Output, mixerNode, NMixerNode.KernelPorts.Inputs, i);
                    ctx.Set.Connect(nWeightNode, NWeight.KernelPorts.OutputWeights, i, mixerNode, NMixerNode.KernelPorts.Weights, i);
                }
            }
        }

        /// <summary>
        /// Rendering data
        /// </summary>
        struct KernelData : IKernelData
        {
            public BlobAssetReference<RigDefinition> RigDefinition;
            public FixedList4096<float>              ClipDurationBuffer;
            public FixedList4096<ClipData>           ClipDataBuffer;
        }


        [BurstCompile(FloatMode = FloatMode.Fast)]
        unsafe struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            private float timeElapsed; // internal time data storage for the next frame.
            private float time;  
            private float weight; // internal weight blended with the external stream. Not nMixer weight. doesnt get connected anywhere, just need to store data for the next frame.
            
            //private ClipBlendState            state;
            private bool                      eventFinished;
            private FixedList4096<EventState> events;


            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                var deltaTime  = context.Resolve(ports.InternalDeltaTime);
                var controller = context.Resolve(ports.Controller);
                var index      = controller.ClipIndex;
                var clip       = data.ClipDataBuffer[index];
                time += deltaTime;

                // Reset the state if the clip is started
                if (controller.PlayClip) // && weight <= 0.15f)
                {
                    eventFinished       = false;
                    controller.PlayClip = false;
                    weight              = 1;
                    //state               = ClipBlendState.BlendIn;
                    timeElapsed         = 0;
                    time                = 0;
                    controller.Events   = new FixedList128<EventState>();
                    // fill events
                    events.Clear();

                    if (clip.Events.IsCreated)
                    {
                        for (var i = 0; i < clip.Events.Value.Events.Length; i++)
                        {
                            var evt = clip.Events.Value.Events[i];
                            events.Add(evt);
                        }
                    }

                    controller.Loop     = data.ClipDataBuffer[index].LoopTime;
                    controller.Duration = data.ClipDataBuffer[index].Duration;

                    context.Resolve(ref ports.OutIndex) = index;
                }

                // Execute clip events
                for (int i = 0; i < events.Length; i++)
                {
                    var evt = events[i];
                    // generally reset the event if the time is zero)
                    if(time.Equals(0))
                    {
                        evt.EventFinished = false;
                        events[i]         = evt;
                    }
                    // if time reaches event time, set the event to finished
                    if (!evt.EventFinished && time >= evt.Time)
                    {
                        evt.EventFinished = true;
                        events[i] = evt;
                        //Debug.Log("Event" + clip.Events.Value.Events[0].FunctionName);
                        controller.Events.Add(evt);
                    }
                }


                if (weight > 0)
                {
                    timeElapsed += deltaTime;
                }

                // If the clip is finished(and not looping), set the weight to 0
                if (timeElapsed >= clip.Duration && !clip.LoopTime)
                {
                    weight = 0;
                    timeElapsed  = 0;
                }
                
                // Blend if time reaches this point
                // note - if this is 0.65, though it blends better the feet position and center of mass will disrupt root positioning
                // if it goes back too soon. to move into an actual configurable parameter.
                var blendTime = clip.Duration * 0.90f; // was 65 
                if (timeElapsed >= blendTime && !clip.LoopTime)
                {
                    if (weight > 0)
                    {
                        weight = math.lerp(weight, 0, deltaTime * 24f);
                    }
                    
                }

                context.Resolve(ref ports.OutController) = controller;
                
                var outputStream = AnimationStream.Create(data.RigDefinition, context.Resolve(ref ports.Output));
                outputStream.ValidateIsNotNull();
                
                var inputStream1 = AnimationStream.CreateReadOnly(data.RigDefinition, context.Resolve(ports.InputStream)); 
                inputStream1.ValidateIsNotNull();
                
                var nMixerStream = AnimationStream.CreateReadOnly(data.RigDefinition, context.Resolve(ports.NMixerStream)); // nMixer stream, THIS IS A TPOSE!
                nMixerStream.ValidateIsNotNull();
                
                outputStream.ClearMasks();

                if (inputStream1.IsNull && nMixerStream.IsNull)
                {
                    outputStream.ResetToDefaultValues();
                }
                else if (inputStream1.IsNull && !nMixerStream.IsNull)
                {
                    outputStream.ResetToDefaultValues();
                    Unity.Animation.Core.Blend(ref outputStream, ref outputStream, ref nMixerStream, weight);
                }
                else if (!inputStream1.IsNull && nMixerStream.IsNull)
                {
                    outputStream.ResetToDefaultValues();
                    Unity.Animation.Core.Blend(ref outputStream, ref inputStream1, ref outputStream, weight);
                }
                else
                {
                    Unity.Animation.Core.Blend(ref outputStream, ref inputStream1, ref nMixerStream, weight);
                }

            }
        }

        InputPortID ITaskPort<IRigContextHandler>.GetPort(NodeHandle handle) => (InputPortID) SimulationPorts.Rig;
        
        
    }

    /// <summary>
    /// Feedback node. Connects to a NMixer node and sets the weight to 1 for the input index. All other clips are set to 0.
    /// </summary>
    internal class NWeight : KernelNodeDefinition<NWeight.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<NWeight, int>               Input;
            public PortArray<DataInput<NWeight, float>>  WeightsN;
            public PortArray<DataOutput<NWeight, float>> OutputWeights;
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                var input = ctx.Resolve(ports.Input);
                var outWeights = ctx.Resolve(ref ports.OutputWeights);
                for (int i = 0; i < outWeights.Length; i++)
                {
                    outWeights[i] = 0;
                }
                outWeights[input] = 1;
            }
        }
    }
}