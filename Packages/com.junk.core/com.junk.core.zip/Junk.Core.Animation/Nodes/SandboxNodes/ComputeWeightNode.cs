using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Mathematics;

namespace CyberJunk.Characters.Graph
{
    public class ClipStreamMixerComputeWeightNode : KernelNodeDefinition<ClipStreamMixerComputeWeightNode.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ClipStreamMixerComputeWeightNode, float> Input;

            public DataOutput<ClipStreamMixerComputeWeightNode, float> OutWeight0;
            public DataOutput<ClipStreamMixerComputeWeightNode, float> OutWeight1;
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                ctx.Resolve(ref ports.OutWeight0) = 0f;
                ctx.Resolve(ref ports.OutWeight1) = 0f;

                // 0-1 clamp
                var w1 = math.modf(math.clamp(ctx.Resolve(ports.Input), 0f, 1f), out float index);
                var w0 = 1f - w1;

                //Debug.Log(ctx.Resolve(ports.Input));
                //Debug.Log(w0 + " - " + w1);//+ " index:"+index);

                if (index < 1f)
                {
                    ctx.Resolve(ref ports.OutWeight0) = w0;
                    ctx.Resolve(ref ports.OutWeight1) = w1;
                }
                else
                {
                    ctx.Resolve(ref ports.OutWeight1) = 1; //w0;
                }
            }
        }
    }
}