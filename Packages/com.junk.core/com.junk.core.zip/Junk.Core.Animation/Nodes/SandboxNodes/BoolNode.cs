using Unity.Burst;
using Unity.DataFlowGraph;
using UnityEngine;

namespace CyberJunk.Characters.Graph
{
    public class BoolDataNode : SimulationKernelNodeDefinition<BoolDataNode.SimPorts, BoolDataNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<BoolDataNode, bool> Play;
            //public MessageOutput<BoolDataNode, bool> Out;
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<BoolDataNode, bool>  Input;
            public DataOutput<BoolDataNode, bool> Output;
        }

        struct Data : INodeData, IInit, IUpdate, IMsgHandler<bool>
        {
            public void Init(InitContext ctx)
            {
                //var thisHandle = ctx.Set.CastHandle<ClipToStreamMixerNode>(ctx.Handle);
                //ctx.Set.Connect(thisHandle, SimulationPorts.Play, thisHandle, BoolDataNode.KernelPorts.Input);
            }

            public void HandleMessage(MessageContext ctx, in bool msg)
            {
                var port   = KernelPorts.Output;
                var handle = ctx.Set.CastHandle<BoolDataNode>(ctx.Handle);


                //GraphValue<float3> nodeGV = ctx.Set.CreateGraphValue(handle, PhysicsVelocityNode.KernelPorts.OuputDelta);
                //ctx.Set.GetValueBlocking(handle);
                //ctx.UpdateKernelData(new KernelData{Value = true});
                //ctx.EmitMessage(KernelPorts.Input, true);
                //ctx.Set.set
            }

            public void Update(UpdateContext context)
            {

            }
        }



        struct KernelData : IKernelData
        {
            public bool Value;
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                if (data.Value)
                {
                    //Debug.Log("bool is true");
                    ctx.Resolve(ref ports.Output) = true; //ctx.Resolve(ports.Input);
                }
            }
        }
    }
}