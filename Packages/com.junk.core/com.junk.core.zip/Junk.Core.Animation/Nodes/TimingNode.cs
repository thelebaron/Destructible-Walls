﻿using Unity.Burst;
using Unity.Collections;
using Unity.DataFlowGraph;
using Unity.Mathematics;
using Unity.Entities;
using UnityEngine;

/// <summary>
/// Until Unity actually implement events, gotta hack n hardcode this shit in
/// </summary>
public enum AnimationEvent
{
    FireBullet,
    SpawnGibs,
}

public struct TimingController : IComponentData
{
    // Clip time control
    public bool  SetTime;
    public float Time;
    
    // Clip loop control
    public bool  Loop;
    public float Duration;
    
    // Clip event control
    public bool  TriggerEvent;
    public float EventTime;
    public float EventDuration;
    public int   EventIndex;
}

public struct EventReadback : IComponentData
{
    public FixedList512<AnimationEvent> Events;
}



namespace Junk.Core.Animation
{
    /// <summary>
    /// Similar to the TimeCounterNode, this has a component that allows for the time to be set from
    /// component data, until it can be replaced by burstable messages.
    /// Note this is super hacky, one component per entity though the node may be used multiple times in a graph.
    /// </summary>
    public class TimingNode : SimulationKernelNodeDefinition<TimingNode.SimPorts, TimingNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<TimingNode, float> Time;
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<TimingNode, float>            DeltaTime;
            public DataInput<TimingNode, float>            Speed;
            public DataInput<TimingNode, TimingController> TimingController;

            public DataOutput<TimingNode, float>            OutputDeltaTime;
            public DataOutput<TimingNode, float>            Time;
            public DataOutput<TimingNode, TimingController> OutputTimingController;
        }

        struct Data : INodeData, IInit, IUpdate, IMsgHandler<float>
        {
            private KernelData m_KernelData;
            private  int       m_SetTime;

            public void Init(InitContext ctx) =>
                ctx.RegisterForUpdate();

            public void Update(UpdateContext ctx)
            {
                if (m_SetTime != 0)
                {
                    m_SetTime = 0;
                }
                else
                {
                    m_KernelData.SetTime = 0;
                    ctx.UpdateKernelData(m_KernelData);
                }
            }

            public void HandleMessage(MessageContext ctx, in float msg)
            {
                if (ctx.Port == SimulationPorts.Time)
                {
                    m_KernelData.Time = msg;
                    m_KernelData.SetTime = 1;
                    m_SetTime = 1;

                    ctx.UpdateKernelData(m_KernelData);
                }
            }
        }

        struct KernelData : IKernelData
        {
            public int SetTime;
            public float Time;
        }

        [BurstCompile /*(FloatMode = FloatMode.Fast)*/]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            float       m_Time;
            
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                var component = context.Resolve(ports.TimingController);
                var speed     = context.Resolve(ports.Speed);
                var deltaTime = context.Resolve(ports.DeltaTime);
                deltaTime *= speed;
                
                var oldTime = m_Time;
                m_Time = math.select(m_Time + deltaTime, data.Time, data.SetTime != 0);
                
                // Component data overrides messaging
                if (component.SetTime)
                {
                    m_Time            = component.Time;
                    component.SetTime = false;
                    oldTime           = m_Time; //reset this flag
                }

                // looping control
                if (component.Loop)
                {
                    if(oldTime >= component.Duration - 0.3f)
                    {
                        m_Time = oldTime;
                    }
                }
                //Debug.Log(m_Time);
                
                //counter++;
                // this code somehow makes time run faster so dont set back time for now(unsure if even needed)
                //m_Time = math.select(m_Time + deltaTime, component.Time, component.SetTime);
                //component.SetTime = false;
                //component.Time = m_Time;

                context.Resolve(ref ports.Time)            = m_Time;
                context.Resolve(ref ports.OutputDeltaTime) = deltaTime;
                context.Resolve(ref ports.OutputTimingController)   = component;
            }
        }
    }
}