using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;

namespace Junk.Core.Animation
{
    public struct AnimationWeight : IComponentData
    {
        public float WeightValue;
    }

    public class ExtractAnimationWeightNode : KernelNodeDefinition<ExtractAnimationWeightNode.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ExtractAnimationWeightNode, AnimationWeight> Input;
            public DataOutput<ExtractAnimationWeightNode, float>          Output;
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                ctx.Resolve(ref ports.Output) = ctx.Resolve(ports.Input).WeightValue;
            }
        }
    }
}