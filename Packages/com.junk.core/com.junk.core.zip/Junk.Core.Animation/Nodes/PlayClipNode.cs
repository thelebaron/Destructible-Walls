using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;

namespace Junk.Core.Animation
{
    /// <summary>
    /// Mixes a single clip with an animation stream.
    /// </summary>
    public class PlayClipNode : SimulationKernelNodeDefinition<PlayClipNode.SimPorts, PlayClipNode.KernelDefs>, IRigContextHandler<PlayClipNode.Data>
    {
        public struct SimPorts : ISimulationPortDefinition
        {

            public MessageInput<PlayClipNode, float> Time; // This is used during gameplay to set the time of the animation clip to 0 to restart it.
            // No specific message handler here as forwarded to time node in initialization. 

            public MessageInput<PlayClipNode, ClipConfiguration> ClipConfiguration;
            public MessageInput<PlayClipNode, Rig>               Rig;

            public MessageInput<PlayClipNode, BlobAssetReference<Clip>> Clip;
            public MessageInput<PlayClipNode, bool>                     Interruptible; //does nothing at the moment
            public MessageInput<PlayClipNode, float>                    Duration;

#pragma warning disable 0649
            internal MessageOutput<PlayClipNode, float>                    m_OutTime; // No specific message handler here as forwarded to time node in initialization.
            internal MessageOutput<PlayClipNode, Rig>                      m_OutRig;
            internal MessageOutput<PlayClipNode, ClipConfiguration>        m_OutConfiguration;
            internal MessageOutput<PlayClipNode, BlobAssetReference<Clip>> m_OutClip;
#pragma warning restore 0649
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<PlayClipNode, Buffer<AnimatedData>> Input; // takes an animation stream
            public DataInput<PlayClipNode, float>                Time; // current time
            public DataInput<PlayClipNode, float>                DeltaTime; // delta time
            public DataInput<PlayClipNode, float>                Speed; //Gets forwarded to the time node parameter for clip playback speed
            public DataInput<PlayClipNode, bool>                 Play; // is connected to m_OutPlay

#pragma warning disable 0649
            internal DataInput<PlayClipNode, Buffer<AnimatedData>> InternalAnimationData;
            internal DataInput<PlayClipNode, float>                InternalDeltaTime;
            internal DataOutput<PlayClipNode, float>               OutTimeElapsed;
            internal DataOutput<PlayClipNode, float>               OutWeight;
#pragma warning restore 0649

            public DataOutput<PlayClipNode, Buffer<AnimatedData>> Output; // animation stream
        }

        /// <summary>
        /// Simulation Data
        /// </summary>
        struct Data
            : INodeData
                , IInit
                , IUpdate
                , IDestroy
                , IMsgHandler<Rig>
                , IMsgHandler<BlobAssetReference<Clip>>
                , IMsgHandler<ClipConfiguration>
                , IMsgHandler<float>
                , IMsgHandler<bool>
        {
            private NodeHandle<TimeCounterNode> timeNode;
            private NodeHandle<UberClipNode>    clip;

            private NodeHandle<KernelPassThroughNodeFloat>
                deltaPassNode; // need to use this passthrough node in order to use its output for two inputs(the TimeCounterNode & InternalDeltaTime

            private KernelData kernelData;

            public void Init(InitContext ctx)
            {
                var thisHandle = ctx.Set.CastHandle<PlayClipNode>(ctx.Handle);
                ctx.RegisterForUpdate();

                deltaPassNode = ctx.Set.Create<KernelPassThroughNodeFloat>();
                timeNode      = ctx.Set.Create<TimeCounterNode>();
                clip          = ctx.Set.Create<UberClipNode>();

                ctx.Set.Connect(deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, timeNode, TimeCounterNode.KernelPorts.DeltaTime);
                ctx.Set.Connect(deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, thisHandle, KernelPorts.InternalDeltaTime);
                ctx.Set.Connect(timeNode, TimeCounterNode.KernelPorts.Time, clip, UberClipNode.KernelPorts.Time);
                ctx.Set.Connect(timeNode, TimeCounterNode.KernelPorts.OutputDeltaTime, clip, UberClipNode.KernelPorts.DeltaTime);

                // Setup internal message connections
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutRig, clip, UberClipNode.SimulationPorts.Rig);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutClip, clip, UberClipNode.SimulationPorts.Clip);
                ctx.Set.Connect(thisHandle, SimulationPorts.m_OutConfiguration, clip, UberClipNode.SimulationPorts.Configuration);
                {
                    // unknown if this works, implemented to remove need for graphSystem.Set.SendMessage(controllerData.PainNodeHandle, PainNode.SimulationPorts.Time, 0);
                    // in combination with message, THOUGH the bool message is not setup....
                    ctx.Set.Connect(thisHandle, SimulationPorts.m_OutTime, timeNode, TimeCounterNode.SimulationPorts.Time);
                }

                // Setup port forwarding
                ctx.ForwardInput(SimulationPorts.Time, timeNode, TimeCounterNode.SimulationPorts.Time);
                ctx.ForwardInput(KernelPorts.DeltaTime, deltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                ctx.ForwardInput(KernelPorts.Speed, timeNode, TimeCounterNode.KernelPorts.Speed);
                ctx.Set.Connect(clip, UberClipNode.KernelPorts.Output, thisHandle, KernelPorts.InternalAnimationData);
            }

            public void Destroy(DestroyContext ctx)
            {
                ctx.Set.Destroy(timeNode);
                ctx.Set.Destroy(clip);
                ctx.Set.Destroy(deltaPassNode);
            }

            public void HandleMessage(MessageContext ctx, in Rig rig)
            {
                ctx.EmitMessage(SimulationPorts.m_OutRig, rig);
                kernelData.RigDefinition = rig;
                ctx.UpdateKernelData(kernelData);

                ctx.Set.SetBufferSize(ctx.Handle, (OutputPortID) KernelPorts.Output,
                    Buffer<AnimatedData>.SizeRequest(rig.Value.IsCreated ? rig.Value.Value.Bindings.StreamSize : 0));
            }

            public void HandleMessage(MessageContext ctx, in float msg)
            {
                if (ctx.Port == SimulationPorts.Duration)
                {
                    kernelData.ClipDuration = msg;
                    ctx.UpdateKernelData(kernelData);
                }

                if (ctx.Port == SimulationPorts.Time)
                    ctx.EmitMessage(SimulationPorts.m_OutTime, 0);
            }

            public void HandleMessage(MessageContext ctx, in bool msg)
            {
                if (ctx.Port == SimulationPorts.Interruptible)
                {
                    kernelData.ClipInterruptible = msg;
                }
            }

            public void HandleMessage(MessageContext ctx, in BlobAssetReference<Clip> clip)
            {
                ctx.EmitMessage(SimulationPorts.m_OutClip, clip);
            }

            public void HandleMessage(MessageContext ctx, in ClipConfiguration clipConfiguration) =>
                ctx.EmitMessage(SimulationPorts.m_OutConfiguration, clipConfiguration);

            public void Update(UpdateContext context)
            {

            }
        }

        /// <summary>
        /// Rendering data
        /// </summary>
        struct KernelData : IKernelData
        {
            public BlobAssetReference<RigDefinition> RigDefinition;
            public float                             ClipDuration;
            public float                             Weight;
            public bool                              ClipInterruptible;
        }


        [BurstCompile(FloatMode = FloatMode.Fast)]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                var     play        = context.Resolve(ports.Play);
                ref var weight      = ref context.Resolve(ref ports.OutWeight);
                var     deltaTime   = context.Resolve(ports.InternalDeltaTime);
                ref var timeElapsed = ref context.Resolve(ref ports.OutTimeElapsed);

                if (play) // && weight <= 0.15f)
                {
                    weight      = 1;
                    timeElapsed = 0;
                }

                if (weight > 0)
                    timeElapsed += deltaTime;

                if (timeElapsed >= data.ClipDuration)
                {
                    weight      = 0;
                    timeElapsed = 0;
                }

                // Blend if time reaches this point
                var blendTime = data.ClipDuration * 0.65f;
                if (timeElapsed >= blendTime)
                {
                    if (weight > 0)
                    {
                        weight = math.lerp(weight, 0, deltaTime * 24f);
                    }
                }

                var outputStream = AnimationStream.Create(data.RigDefinition, context.Resolve(ref ports.Output));

                var inputStream1 = AnimationStream.CreateReadOnly(data.RigDefinition, context.Resolve(ports.Input));
                var inputStream2 = AnimationStream.CreateReadOnly(data.RigDefinition, context.Resolve(ports.InternalAnimationData));

                outputStream.ClearMasks();

                if (inputStream1.IsNull && inputStream2.IsNull)
                    outputStream.ResetToDefaultValues();
                else if (inputStream1.IsNull && !inputStream2.IsNull)
                {
                    outputStream.ResetToDefaultValues();
                    Unity.Animation.Core.Blend(ref outputStream, ref outputStream, ref inputStream2, weight);
                }
                else if (!inputStream1.IsNull && inputStream2.IsNull)
                {
                    outputStream.ResetToDefaultValues();
                    Unity.Animation.Core.Blend(ref outputStream, ref inputStream1, ref outputStream, weight);
                }
                else
                    Unity.Animation.Core.Blend(ref outputStream, ref inputStream1, ref inputStream2, weight);
            }
        }

        InputPortID ITaskPort<IRigContextHandler>.GetPort(NodeHandle handle) => (InputPortID) SimulationPorts.Rig;
    }
}