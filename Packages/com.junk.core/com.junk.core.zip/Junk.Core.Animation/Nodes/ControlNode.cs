using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;

// bool control node


namespace CyberJunk.Graph
{
    public struct ControlInput : IComponentData
    {
        public bool PlayAnimA;
        public bool PlayAnimB;
        public bool PlayAnimC;
    }

    public class ControlNode : KernelNodeDefinition<ControlNode.KernelDefs>
    {
        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ControlNode, ControlInput> Input;

            public DataOutput<ControlNode, bool> PlayAnimA;
            public DataOutput<ControlNode, bool> PlayAnimB;
            public DataOutput<ControlNode, bool> PlayAnimC;
        }

        struct KernelData : IKernelData
        {
        }



        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                var input = ctx.Resolve(ports.Input); //SimpleDataInput
                ctx.Resolve(ref ports.PlayAnimA) = input.PlayAnimA;
                ctx.Resolve(ref ports.PlayAnimB) = input.PlayAnimB;
                ctx.Resolve(ref ports.PlayAnimC) = input.PlayAnimC;
            }
        }
    }
}