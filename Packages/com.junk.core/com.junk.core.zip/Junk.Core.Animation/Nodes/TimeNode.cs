using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Mathematics;

namespace Junk.Core.Animation
{
    //Accumulates and output's current time based on scale and delta time
    public class TimeNode : SimulationKernelNodeDefinition<TimeNode.SimPorts, TimeNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<TimeNode, float> Time;
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<TimeNode, DeltaTime> Input; 
            
            public DataInput<TimeNode, float>     SpeedA;
            public DataInput<TimeNode, float>     SpeedB;

            public DataOutput<TimeNode, float> OutputDeltaTimeA; //why was this duplicated?
            public DataOutput<TimeNode, float> OutputDeltaTimeB; //why was this duplicated?
            public DataOutput<TimeNode, float> TimeA;
            public DataOutput<TimeNode, float> TimeB;
            
            
        }

        struct Data : INodeData, IInit, IUpdate, IMsgHandler<float>, IMsgHandler<int>
        {
            KernelData m_KernelData;
            int m_SetTime;

            public void Init(InitContext ctx) => ctx.RegisterForUpdate();

            public void Update(UpdateContext ctx)
            {
                if (m_SetTime != 0)
                {
                    m_SetTime = 0;
                }
                else
                {
                    m_KernelData.SetTime = 0;
                    ctx.UpdateKernelData(m_KernelData);
                }
            }

            public void HandleMessage(MessageContext ctx, in float msg)
            {
                if (ctx.Port == SimulationPorts.Time)
                {
                    m_KernelData.Time = msg;
                    m_KernelData.SetTime = 1;
                    m_SetTime = 1;

                    ctx.UpdateKernelData(m_KernelData);
                }
            }

            /// <summary>
            /// Unused: Resize the port array to the specified count
            /// </summary>
            public void HandleMessage(MessageContext ctx, in int msg)
            {
                m_KernelData.Count = msg;
            }
        }

        struct KernelData : IKernelData
        {
            public int   SetTime;
            public float Time;
            public int   Count;
        }

        [BurstCompile /*(FloatMode = FloatMode.Fast)*/]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            float m_TimeA;
            float m_TimeB;
            public void Execute(RenderContext context, in KernelData data, ref KernelDefs ports)
            {
                var deltaTimeA = context.Resolve(ports.Input).Value * context.Resolve(ports.SpeedA);
                var deltaTimeB = context.Resolve(ports.Input).Value * context.Resolve(ports.SpeedB);
                
                m_TimeA = math.select(m_TimeA + deltaTimeA, data.Time, data.SetTime != 0);
                m_TimeB = math.select(m_TimeB + deltaTimeB, data.Time, data.SetTime != 0);

                context.Resolve(ref ports.TimeA)           = m_TimeA;
                context.Resolve(ref ports.TimeB)           = m_TimeB;
                
                context.Resolve(ref ports.OutputDeltaTimeA) = deltaTimeA;
                context.Resolve(ref ports.OutputDeltaTimeB) = deltaTimeB;
            }
        }
    }
}
