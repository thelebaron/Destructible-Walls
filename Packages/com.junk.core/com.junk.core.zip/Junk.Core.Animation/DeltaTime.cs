using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;

namespace Junk.Core.Animation
{
    public struct DeltaTime : IComponentData
    {
        public float Value;
    }

    [UpdateBefore(typeof(DefaultAnimationSystemGroup))]
    public class DeltaTimeSystem : SystemBase
    {
        protected override void OnUpdate()
        {
            var worldDeltaTime = World.Time.DeltaTime;
            Entities.ForEach((Entity entity, ref DeltaTime deltaTime) =>
            {
                deltaTime.Value = worldDeltaTime;
            }).ScheduleParallel();
        }
    }  
}