using Unity.Animation;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Transforms;

namespace Junk.Core.Animation
{
    /// <summary>
    /// A buffer of animated bones.
    /// </summary>
    public struct RigBones : IBufferElementData
    {
        public Entity Entity;
    }
}


    /// <summary>
    /// A ragdoll is a set of bones that are connected to each other.
    /// Root control component. Enable/disable to enable/disable the ragdoll.
    /// </summary>
    public struct PhysicsRagdoll : IComponentData
    {
        public bool                              Enabled;
        public BlobAssetReference<RigDefinition> Value;
        public float4x4                          Matrix;//deprecated
    }

    /// <summary>
    /// A buffer of rigidbodies
    /// </summary>
    public struct PhysicsRig : IBufferElementData
    {
        public Entity RigidEntity;
        public float4x4 Transform;
    }
    