﻿using Unity.Collections;
using Unity.Entities;
using UnityEngine;

namespace Junk.Core.Animation
{
    public struct AnimEvent
    {
        public float         Time;
        public FixedString32 FunctionName;
        public FixedString32 StringParameter;
        public float         FloatParameter;
        public int           IntParameter;
        //public Entity        EntityReference;
        //public int           MessageOptions;
        /*public AnimationEventSource m_Source;
        public AnimationState       m_StateSender;
        public AnimatorStateInfo    m_AnimatorStateInfo;
        public AnimatorClipInfo     m_AnimatorClipInfo;*/
    }
    
    
    public struct EventState
    {
        public bool          EventFinished;
        public float         Time;
        public FixedString32 FunctionName;
        public FixedString32 StringParameter;
        public float         FloatParameter;
        public int           IntParameter;
            
        // methods to cast to EventAnimation
        public static implicit operator EventState(AnimEvent e)
        {
            return new EventState
            {
                Time            = e.Time,
                FunctionName    = e.FunctionName,
                StringParameter = e.StringParameter,
                FloatParameter  = e.FloatParameter,
                IntParameter    = e.IntParameter
            };
        }
            
        // methods to cast from EventAnimation
        public static implicit operator AnimEvent(EventState e)
        {
            return new AnimEvent
            {
                Time            = e.Time,
                FunctionName    = e.FunctionName,
                StringParameter = e.StringParameter,
                FloatParameter  = e.FloatParameter,
                IntParameter    = e.IntParameter
            };
        }
    }
    
    [BurstCompatible]
    public struct ClipEvents
    {
        public bool                 HasEvents;
        public BlobArray<AnimEvent> Events;

        public static BlobAssetReference<ClipEvents> ToBlobData(AnimationClip clip)
        {
            var     builder = new BlobBuilder(Allocator.Temp);
            ref var root     = ref builder.ConstructRoot<ClipEvents>();
            root.HasEvents = clip.events.Length > 0;
            
            var array = builder.Allocate<AnimEvent>(ref root.Events, clip.events.Length);
            for (int i = 0; i < array.Length; i++)
            {
                var oldEvent = clip.events[i];
                
                var newEvent = new AnimEvent
                {
                 Time            = oldEvent.time,
                 FunctionName    = oldEvent.functionName,
                 StringParameter = oldEvent.stringParameter,
                 FloatParameter  = oldEvent.floatParameter,
                 IntParameter    = oldEvent.intParameter,
                 //MessageOptions  = oldEvent.messageOptions,
                };
                
                array[i] = newEvent;
            }
            
            var blob = builder.CreateBlobAssetReference<ClipEvents>(Allocator.Persistent);
            root = ref blob.Value;
            
            builder.Dispose();

            return blob;
        }
    }

    public static class ClipEventConversion
    {
        /// <summary>
        /// Converts a UnityEngine AnimationClip to a DOTS dense clip.
        ///
        /// NOTE: This extension is not supported in the Player.
        /// </summary>
        /// <param name="sourceClip">The UnityEngine.AnimationClip to convert to a DOTS dense clip format.</param>
        /// <param name="hasher">An optional BindingHashGenerator can be specified to compute unique animation binding IDs. When not specified the <see cref="BindingHashGlobals.DefaultHashGenerator"/> is used.</param>
        /// <returns>Returns a dense clip BlobAssetReference</returns>
        public static BlobAssetReference<ClipEvents> ToEvents(this AnimationClip sourceClip)
        {
            return ClipEvents.ToBlobData(sourceClip);
        }
    }
}