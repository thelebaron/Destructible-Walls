using Unity.Entities;

namespace Junk.Core.Animation
{
    /// <summary>
    /// Small timer system to determine state actions. The time system only increases and sets the flag to true if
    /// the current time value is greater/equal than the predetermined nextthink value. Other systems are responsible
    /// for resetting Ready and NextThink value.
    /// </summary>
    public struct Think : IComponentData
    {
        public float Time;
        public float NextThink;

        public bool Action => Time >= NextThink; //wait what the hell?

        /*public static implicit operator float(Think t)
        {
            return t.Value;
        }*/
    }
}