using CyberJunk.Graph;
using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;
using Random = Unity.Mathematics.Random;

namespace Junk.Core.Animation
{
    public struct Npc : IComponentData
    {
        /*
         * -1 - player
         * 0 - main enemies
        */
        public float PainChance; // set above 0
        
        public float3 Destination;
        public float  Distance;
        public bool   ReachedDestination;
        public bool   ShouldRotateTowardsTarget;
        
        public float3 Direction;
        public float  TurnSpeed;
        public float  CurrentSpeed;
        public int    Team;
        public float  SightRadius; //Cell Radius

        public Random Random;

        [BurstCompile]
        public float GetDistance(float3 position, float3 target)
        {
            Distance = math.distance(position, target);
            return Distance;
        }
    }
    
    
    public struct NpcAnimGraphSetup : IComponentData
    {
        public BlobAssetReference<Clip> SingleClip;
        public BlobAssetReference<Clip> IdleClip;
        public BlobAssetReference<Clip> WalkClip;
        public BlobAssetReference<Clip> RunClip;

        public ClipConfiguration Configuration;
    }


    /// <summary>
    /// why is this systemstate>? to dispose of graph handles when teardown
    /// this is set by system jobs
    /// </summary>
    public struct SampleNpcGraphInputs : ISystemStateComponentData
    {
        public GraphHandle                     Graph;
        public RigidTransform                  FollowX;
        /*public NodeHandle<PhysicsVelocityNode> PhysicsNodeHandle;*/


        public float                    Direction;
        public float                    DirectionDamped;
        public float                    Speed;
        public float                    SpeedDamped;
        public NodeHandle<PlayClipNode> ToggleClipNodeHandle;
    }
}