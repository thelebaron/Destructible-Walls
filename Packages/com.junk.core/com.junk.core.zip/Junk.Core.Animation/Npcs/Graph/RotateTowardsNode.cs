using CyberJunk.Entities;
using Junk.Math;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Mathematics;
using Unity.Transforms;

namespace Junk.Core.Animation
{
    public class RotateTowardsNode : SimulationKernelNodeDefinition<RotateTowardsNode.SimPorts, RotateTowardsNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageOutput<RotateTowardsNode, float3> OutputData; // manual data access
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<RotateTowardsNode, float>        DeltaTime;
            public DataInput<RotateTowardsNode, Npc>          Npc;
            public DataInput<RotateTowardsNode, LocalToWorld> LocalToWorld;
            public DataInput<RotateTowardsNode, Rotation>     Rotation;

            public DataOutput<RotateTowardsNode, Rotation> Output; // data filled in a system
        }

        struct KernelData : IKernelData
        {
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                var deltaTime    = ctx.Resolve(ports.DeltaTime);
                var npc          = ctx.Resolve(ports.Npc);
                var localToWorld = ctx.Resolve(ports.LocalToWorld);
                var rotation     = ctx.Resolve(ports.Rotation);

                // RotateTowardsPoint
                var pos = localToWorld.Position;
                var dir = npc.Destination - pos;
                dir.y = 0;
                var r = quaternion.identity;
                if (!dir.Equals(float3.zero))
                    r = quaternion.LookRotation(dir, maths.up);

                var oldRot = rotation.Value;
                var newRot = math.slerp(rotation.Value, r, (npc.TurnSpeed * 0.04f) * deltaTime);
                var rot    = new Rotation {Value = maths.select(oldRot, newRot, npc.ShouldRotateTowardsTarget)};

                //var storedRot = ctx.Resolve(ref ports.Output);
                ctx.Resolve(ref ports.Output) = rot;
            }
        }
    }
}