using Junk.Math;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;
using Random = Unity.Mathematics.Random;

namespace Junk.Core.Animation
{
    public class WanderNode : SimulationKernelNodeDefinition<WanderNode.SimPorts, WanderNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<WanderNode, float> WanderDuration; // get a new destination every x seconds
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public   DataInput<WanderNode, float>            DeltaTime;
            public   DataOutput<WanderNode, WanderBehaviour> Output;
            internal DataOutput<WanderNode, float>           WanderTimeInternal;
        }

        struct Data : IInit, INodeData, IUpdate, IMsgHandler<Entity>, IMsgHandler<float>
        {
            KernelData m_KernelData;

            public void Init(InitContext ctx)
            {
                var seed = (uint) UnityEngine.Random.Range(1, 100000);
                m_KernelData.Random     = new Random(seed);
                m_KernelData.WanderTime = 5;
                ctx.UpdateKernelData(m_KernelData);
                ctx.RegisterForUpdate();
            }

            public void HandleMessage(MessageContext ctx, in Entity msg)
            {
                var seed = (uint) msg.Index + (uint) msg.Version;
                m_KernelData.Random = new Random((uint) new Random(seed).NextInt());
                ctx.UpdateKernelData(m_KernelData);
            }

            public void HandleMessage(MessageContext ctx, in float msg)
            {
                m_KernelData.WanderTime = msg;
                ctx.UpdateKernelData(m_KernelData);
            }

            [BurstCompile]
            public void Update(UpdateContext ctx)
            {
                m_KernelData.Destination = m_KernelData.Random.insideSphere() * m_KernelData.Random.NextFloat(1.09925f, 15f);
                //m_KernelData.Destination = UnityEngine.Random.insideUnitSphere * 15;
                ctx.UpdateKernelData(m_KernelData);
            }
        }

        struct KernelData : IKernelData
        {
            public float  WanderTime;
            public Random Random;
            public float3 Destination;
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                //var     enabled    = ctx.Resolve(ports.Enabled);
                //ref var ri              = ref ctx.Resolve(ref ports.RandomInternal);
                var     deltaTime       = ctx.Resolve(ports.DeltaTime);
                ref var wanderComponent = ref ctx.Resolve(ref ports.Output);
                ref var wanderTime      = ref ctx.Resolve(ref ports.WanderTimeInternal);
                wanderTime += deltaTime;

                var random       = data.Random;
                var range        = random.NextFloat(1.09925f, 15f);
                var insideSphere = random.insideSphere() * range;
                var vector       = insideSphere;
                vector.y = 0;

                // note refactor removed Destination field, so this is just left in as what this node used to do.
                ////////wanderComponent.Destination = math.@select(wanderComponent.Destination, data.Destination, wanderTime >= data.WanderTime);
                wanderTime = math.@select(wanderTime, 0, wanderTime > data.WanderTime);
            }

            /*[BurstCompile]
            static float3 Destination(ref KernelData data)
            {
                //var seed = (uint)12345;
                //var random = new Random((uint) new Random(seed).NextInt());
                
                var r            = data.Random;
                var range        = r.NextFloat(5.09925f, 15f);
                var insideSphere = r.insideSphere() * range;
                var vector       = insideSphere;
                vector.y = 0;
    
                //Debug.Log(vector);
                return vector;
            }*/
        }
    }
}