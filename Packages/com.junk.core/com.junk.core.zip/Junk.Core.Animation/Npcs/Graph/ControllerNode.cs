using Unity.Animation;
using Unity.Burst;
using Unity.DataFlowGraph;
using Unity.Entities;
using Unity.Mathematics;
using Debug = UnityEngine.Debug;

namespace Junk.Core.Animation
{
    /// <summary>
    /// this is set by node
    /// </summary>
    public struct NpcGraphInternal : IComponentData
    {
        public bool  PlaySingleAnimationClip;
        public float MovementWeight;
        public float TimeCounterSpeed;
    }
    
    

    /// <summary>
    /// Relays ECS input data through to GraphNode data
    /// </summary>
    public class ControllerNode : SimulationKernelNodeDefinition<ControllerNode.SimPorts, ControllerNode.KernelDefs>
    {
        public struct SimPorts : ISimulationPortDefinition
        {
            public MessageInput<ControllerNode, bool> Enabled;
        }

        public struct KernelDefs : IKernelPortDefinition
        {
            public DataInput<ControllerNode, float>            DeltaTime;
            public DataInput<ControllerNode, SampleNpcGraphInputs>   NpcGraphInputs;
            public DataInput<ControllerNode, NpcGraphInternal> NpcGraphInternalComponent;
            
            public DataOutput<ControllerNode, bool>             PlaySingleAnim;
            public DataOutput<ControllerNode, float>            Speed;
            public DataOutput<ControllerNode, float>            MovementWeight;
            public DataOutput<ControllerNode, NpcGraphInternal> Output;
        }

        struct Data : INodeData, IInit, IDestroy, IMsgHandler<bool>
        {
            //private NodeHandle<WanderNode>                m_WanderNode;
            private NodeHandle<KernelPassThroughNodeFloat> m_DeltaPassNode;

            public void Init(InitContext ctx)
            {
                var thisHandle = ctx.Set.CastHandle<ControllerNode>(ctx.Handle);
                //m_WanderNode    = ctx.Set.Create<WanderNode>();
                m_DeltaPassNode = ctx.Set.Create<KernelPassThroughNodeFloat>();

                //ctx.Set.Connect(thisHandle, KernelPorts.DeltaTime, m_DeltaPassNode, WanderNode.KernelPorts.DeltaTime);
                //ctx.Set.Connect(m_DeltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, m_WanderNode, WanderNode.KernelPorts.DeltaTime);
                //ctx.ForwardInput(KernelPorts.DeltaTime, m_DeltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Input);
                
                //ctx.Set.Connect(m_WanderNode, WanderNode.KernelPorts.DeltaTime, );
                //ctx.Set.Connect(m_DeltaPassNode, KernelPassThroughNodeFloat.KernelPorts.Output, thisHandle, KernelPorts.DeltaTime);

                // Setup port forwarding
            }

            public void HandleMessage(MessageContext ctx, in bool msg)
            {
            }

            public void Destroy(DestroyContext context)
            {
                //context.Set.Destroy(m_WanderNode);
                context.Set.Destroy(m_DeltaPassNode);
            }
        }

        struct KernelData : IKernelData
        {
            public bool Enabled;
        }

        [BurstCompile]
        struct Kernel : IGraphKernel<KernelData, KernelDefs>
        {
            public void Execute(RenderContext ctx, in KernelData data, ref KernelDefs ports)
            {
                var animGraph      = ctx.Resolve(ports.NpcGraphInternalComponent);
                var graphInputs = ctx.Resolve(ports.NpcGraphInputs);
                var deltaTime      = ctx.Resolve(ports.DeltaTime);
                
                // speed
                var dampWeight = deltaTime / 0.015f;
                var speed      = math.select(0, graphInputs.Speed, true); //TODO move this to PhysicsMovement.Enabled
                //graphInputs.DirectionDamped = math.lerp(graphInputs.DirectionDamped, graphInputs.Direction, dampWeight);
                graphInputs.SpeedDamped     = math.lerp(graphInputs.SpeedDamped, speed, dampWeight);
                animGraph.TimeCounterSpeed     = 1.0f * graphInputs.SpeedDamped;
                animGraph.MovementWeight       = math.clamp(graphInputs.SpeedDamped * 2, 0, 2.0f);
                //animGraph.MovementSpeed      = math.clamp(controllerData.SpeedDamped * 2, 0, 2.0f);

                ctx.Resolve(ref ports.PlaySingleAnim)   = animGraph.PlaySingleAnimationClip;
                ctx.Resolve(ref ports.Speed) = animGraph.TimeCounterSpeed;
                ctx.Resolve(ref ports.MovementWeight)   = animGraph.MovementWeight;
                //ctx.Resolve(ref ports.MovementSpeed)   = animGraph.MovementSpeed;

                // Reset trigger values
                animGraph.PlaySingleAnimationClip = false;
                ctx.Resolve(ref ports.Output)     = animGraph;
            }
        }
    }
}