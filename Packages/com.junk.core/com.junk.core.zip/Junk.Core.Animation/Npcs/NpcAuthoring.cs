using System;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

namespace Junk.Core.Animation
{ 
    [Obsolete]
    [ConverterVersion("chris",1)]
    public class NpcAuthoring : MonoBehaviour, IConvertGameObjectToEntity, IDeclareReferencedPrefabs
    {
        public string Name;
        public bool   WanderBehaviour = true;
        public float  PainChance      = 0.9f;
        public float  TurnSpeed       = 1;
        public int    Team            = 0;
        public float  SightRadius     = 30;
        
        public void Convert(Entity                            entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            var npc  = new Npc();
            npc.Random      = new Unity.Mathematics.Random((uint)12345 ); // note the spawnersystem modifies this, during conversion all of these are the same if spawned from an entity prefab
            npc.PainChance  = PainChance;
            npc.TurnSpeed   = TurnSpeed;
            npc.Team        = Team;
            npc.SightRadius = SightRadius;
            
            if (WanderBehaviour)
            {
                dstManager.AddComponent<WanderBehaviour>(entity);
            }

            dstManager.AddComponentData(entity, npc);
            var think = new Think {Time = UnityEngine.Random.Range(0, 1f)};
            dstManager.AddComponentData(entity, think);


        }

        public void DeclareReferencedPrefabs(List<GameObject> referencedPrefabs)
        {
            
        }
    }
    
    public struct WanderBehaviour : IComponentData
    {
        //public float3 Destination;
    }
}