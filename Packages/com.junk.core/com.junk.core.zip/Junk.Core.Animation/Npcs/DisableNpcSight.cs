using Unity.Entities;

namespace Junk.Core.Animation
{
    /// <summary>
    /// By default npcs always will be added to the sight system. This tag disables this behaviour.
    /// </summary>
    public struct DisableNpcSight : IComponentData
    {
    }
}