using CyberJunk.Entities;
using Junk.Core.Entities;
using Junk.Math;
using Unity.Animation;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
[DisableAutoCreation]
[UpdateInGroup(typeof(LateAnimationSystemGroup))]
[UpdateAfter(typeof(ComputeRigMatrices))]
public class PushRagdollToMatrixSystem : SystemBase
{
    private EntityQuery ragdollQuery;

    protected override void OnCreate()
    {
        ragdollQuery = GetEntityQuery(typeof(PhysicsRagdoll), typeof(PhysicsRig), typeof(AnimatedLocalToRoot));
    }

    private float timer;
    private bool  logRigIndicies;
    int           k_skinMeshIndex;

    [BurstCompile]
    struct PushRagdollDataJob : IJobEntityBatch
    {
        [ReadOnly] public                            EntityTypeHandle                               EntityType;
        [ReadOnly] public                            ComponentTypeHandle<PhysicsRagdoll>              RagdollControllerType;
        [ReadOnly] public                            BufferTypeHandle<PhysicsRig>                  RagdollBoneType;
        public                                       BufferTypeHandle<AnimatedLocalToRoot>          AnimatedLocalToRootType;
        [ReadOnly]                            public ComponentDataFromEntity<LocalToWorld>          LocalToWorldData;
        [ReadOnly]                            public BufferFromEntity<Child>                        EntityChild;
        [NativeDisableParallelForRestriction] public BufferFromEntity<SkinnedMeshToRigIndexMapping> SkinnedMeshToRigIndexMappingBuffer;

        public void Execute(ArchetypeChunk batchInChunk, int batchIndex)
        {
            var entities             = batchInChunk.GetNativeArray(EntityType);
            var ragdollControllers   = batchInChunk.GetNativeArray(RagdollControllerType);
            var ragdollBones       = batchInChunk.GetBufferAccessor(RagdollBoneType);
            var animatedLocalToRoots = batchInChunk.GetBufferAccessor(AnimatedLocalToRootType);

            for (var i = 0; i < entities.Length; i++)
            {
                var entity                    = entities[i]; // this is the rig entity
                var ragdollController         = ragdollControllers[i];
                var bones                     = ragdollBones[i];
                var animatedLocalToRootBuffer = animatedLocalToRoots[i];

                // Dont set bone matrices to ragdoll positions if we arent in a ragdoll state
                if (!ragdollController.Enabled)
                    continue;

                // Transpose ragdoll transform to skinnedMesh transform
                LocalToWorld localToWorld = default;

                // Iterate through every child skinned mesh
                var children = EntityChild[entity];
                for (int j = 0; j < children.Length; j++)
                {
                    var child = children[j].Value;

                    // Ignore if child entity does not have mesh to rig mapping buffer
                    if (!child.HasComponent(SkinnedMeshToRigIndexMappingBuffer))
                    {
                        continue;
                    }

                    // Get the mapping buffer on skinned rendermesh entity
                    var rigIndexMappings = SkinnedMeshToRigIndexMappingBuffer[child];

                    // Iterate through all mappings
                    for (int k = 0; k < rigIndexMappings.Length; k++)
                    {
                        var rigIndexMapping     = rigIndexMappings[k];
                        var rigIndex = rigIndexMapping.RigIndex;
                        var skinIndex = rigIndexMapping.SkinMeshIndex;
                        
                        var rigidEntity = bones[k].RigidEntity;

                        if (rigidEntity.Equals(Entity.Null))
                        {
                            continue;
                        }
                        
                        //if (!rigidEntity.Equals(Entity.Null))
                        localToWorld = LocalToWorldData[rigidEntity];

                        // must offset see https://stackoverflow.com/questions/10176456/subtracting-two-4x4-matrices-is-this-possible for math
                        // matrixOffset = inverse(matrixAtFrame0) * matrixAtFrameX
                        var offset                    = math.mul(math.inverse(ragdollController.Matrix), localToWorld.Value);
                        var animatedLocalToRootMatrix = float4x4.TRS(GetTranslation(offset), new quaternion(offset), maths.one);

                        animatedLocalToRootBuffer[rigIndexMapping.RigIndex] = new AnimatedLocalToRoot {Value = animatedLocalToRootMatrix};
                    }
                }
            }
        }
    }

    protected override void OnUpdate()
    {
        Dependency = new PushRagdollDataJob
        {
            EntityType                         = GetEntityTypeHandle(),
            RagdollControllerType              = GetComponentTypeHandle<PhysicsRagdoll>(true),
            RagdollBoneType                    = GetBufferTypeHandle<PhysicsRig>(true),
            AnimatedLocalToRootType            = GetBufferTypeHandle<AnimatedLocalToRoot>(),
            LocalToWorldData                   = GetComponentDataFromEntity<LocalToWorld>(true),
            EntityChild                        = GetBufferFromEntity<Child>(true),
            SkinnedMeshToRigIndexMappingBuffer = GetBufferFromEntity<SkinnedMeshToRigIndexMapping>()
        }.Schedule(ragdollQuery, Dependency);

        /*Entities.WithAll<RagdollController>().ForEach((
            Entity                    entity,
            
            DynamicBuffer<SkinMatrix> skinMatricesBuffer,
            DynamicBuffer<BindPose> bindPoses, 
            DynamicBuffer<SkinnedMeshToRigIndexMapping> skinnedMeshToRigIndexMappings,
            DynamicBuffer<RagdollBuffer>           physicsBodyMapping,
            ref RagdollController            ragdollController,
            in  RigEntity                               rigEntity
            
            ) =>
        {
            // Recreating ComputeDeformationDataBase.cs ComputeSkinMatrices method
            //really? gotta get the offsets..
            var rig               = rigEntity.Value;
            var animatedLTR       = GetBuffer<AnimatedLocalToRoot>(rig);
            var animatedLTW       = GetBuffer<AnimatedLocalToWorld>(rig);
            var rigRootL2W        = GetComponent<LocalToWorld>(GetComponent<RigRootEntity>(rig).Value).Value;
            var smrRootL2W        = GetComponent<LocalToWorld>(ragdollController.BoneEntity).Value;
            var smr2RigRootOffset = math.mul(math.inverse(smrRootL2W), rigRootL2W);

            //Debug.Log("cant");
            if (!ragdollController.IsRagdoll)
                return;

            // Transpose ragdoll transform to skinnedMesh transform
            var localToWorld = new LocalToWorld();

            for (var i = 0; i < skinnedMeshToRigIndexMappings.Length; i++)
            {
                SkinnedMeshToRigIndexMapping mapping     = skinnedMeshToRigIndexMappings[i];
                var rigidEntity = physicsBodyMapping[i].Value;

                if (!rigidEntity.Equals(Entity.Null))
                    localToWorld = GetComponent<LocalToWorld>(rigidEntity);

                // must offset see https://stackoverflow.com/questions/10176456/subtracting-two-4x4-matrices-is-this-possible for math
                // matrixOffset = inverse(matrixAtFrame0) * matrixAtFrameX
                var offset                    = math.mul(math.inverse(ragdollController.Matrix), localToWorld.Value);
                var animatedLocalToRootMatrix = float4x4.TRS(GetTranslation(offset), new quaternion(offset), maths.one);
                
                animatedLTR[mapping.RigIndex] = new AnimatedLocalToRoot {Value = animatedLocalToRootMatrix };
                //animatedLTW[mapping.RigIndex] = new AnimatedLocalToWorld();
                //var skinMat = math.mul(math.mul(smr2RigRootOffset, animatedLocalToRootMatrix), bindPoses[mapping.SkinMeshIndex].Value);


                // so i guess this does nothing
                //float4x4 skinMat = math.mul(math.mul(smr2RigRootOffset, animatedLocalToRootMatrix), bindPoses[mapping.SkinMeshIndex].Value);
                //
                //var skinMatrix = new SkinMatrix
                //{
                //    Value = new float3x4(skinMat.c0.xyz, skinMat.c1.xyz, skinMat.c2.xyz, skinMat.c3.xyz)
                //};
                //skinMatricesBuffer[i] = skinMatrix;
            }
        }).Schedule();*/
    }

    private static float3 GetTranslation(float4x4 matrix)
    {
        return new float3(matrix.c3.x, matrix.c3.y, matrix.c3.z);
    }
}
