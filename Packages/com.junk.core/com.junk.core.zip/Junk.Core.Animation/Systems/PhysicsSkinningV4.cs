﻿using Junk.Math;
using Unity.Animation;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

namespace Junk.Core.Animation
{
    [UpdateInGroup(typeof(LateAnimationSystemGroup))]
    [UpdateAfter(typeof(ComputeRigMatrices))]
    public class PhysicsSkinningSystemV4 : SystemBase
    {
        private EntityQuery ragdollQuery;

        protected override void OnCreate()
        {
            ragdollQuery = GetEntityQuery(typeof(PhysicsRagdoll), typeof(PhysicsRig), typeof(RigBones), typeof(AnimatedLocalToRoot));
        }

        [BurstCompile]
        struct PushRagdollDataJob : IJobEntityBatch
        {
            [ReadOnly] public EntityTypeHandle                      EntityType;
            [ReadOnly] public ComponentTypeHandle<PhysicsRagdoll>     RagdollControllerType;
            [ReadOnly] public BufferTypeHandle<RigBones>            RigBonesType;
            [ReadOnly] public BufferTypeHandle<PhysicsRig>          PhysicsRigType;
            public            BufferTypeHandle<AnimatedLocalToRoot> AnimatedLocalToRootType;
            [ReadOnly] public ComponentDataFromEntity<LocalToWorld> EntityLocalToWorld;

            public void Execute(ArchetypeChunk batchInChunk, int batchIndex)
            {
                var entities             = batchInChunk.GetNativeArray(EntityType);
                var ragdollControllers   = batchInChunk.GetNativeArray(RagdollControllerType);
                var rigBonesAccessor     = batchInChunk.GetBufferAccessor(RigBonesType);
                var physicsRigAccessor   = batchInChunk.GetBufferAccessor(PhysicsRigType);
                var animatedLocalToRoots = batchInChunk.GetBufferAccessor(AnimatedLocalToRootType);

                for (var i = 0; i < batchInChunk.Count; i++)
                {
                    var rigEntity                 = entities[i]; // this is the rig entity
                    var ragdollController         = ragdollControllers[i];
                    var rigBonesBuffer            = rigBonesAccessor[i]; // physics bones - note in this iteration no colliders/physics components on these entities
                    var physicsRigBuffer          = physicsRigAccessor[i];
                    var animatedLocalToRootBuffer = animatedLocalToRoots[i];
                    var matrix                    = EntityLocalToWorld[rigEntity].Value;

                    // Dont set bone matrices to ragdoll positions if we arent in a ragdoll state
                    if (!ragdollController.Enabled)
                        continue;

                    for (int j = 1; j < rigBonesBuffer.Length; j++)
                    {
                        var rigBoneEntity = rigBonesBuffer[j].Entity;
                        var id            = j;
                        
                        // must offset see https://stackoverflow.com/questions/10176456/subtracting-two-4x4-matrices-is-this-possible for math
                        // matrixOffset = inverse(matrixAtFrame0) * matrixAtFrameX
                        var offset                    = math.mul(math.inverse(matrix), EntityLocalToWorld[rigBoneEntity].Value);
                        var animatedLocalToRootMatrix = float4x4.TRS(GetTranslation(offset), new quaternion(offset), maths.one);

                        animatedLocalToRootBuffer[id] = new AnimatedLocalToRoot {Value = animatedLocalToRootMatrix};
                    }
                }
            }
        }

        protected override void OnUpdate()
        {
            Dependency = new PushRagdollDataJob
            {
                EntityType              = GetEntityTypeHandle(),
                RagdollControllerType   = GetComponentTypeHandle<PhysicsRagdoll>(true),
                RigBonesType            = GetBufferTypeHandle<RigBones>(true),
                PhysicsRigType          = GetBufferTypeHandle<PhysicsRig>(true),
                AnimatedLocalToRootType = GetBufferTypeHandle<AnimatedLocalToRoot>(),
                EntityLocalToWorld      = GetComponentDataFromEntity<LocalToWorld>(true),
            }.Schedule(ragdollQuery, Dependency);
        }

        private static float3 GetTranslation(float4x4 matrix)
        {
            return new float3(matrix.c3.x, matrix.c3.y, matrix.c3.z);
        }
    } 
}