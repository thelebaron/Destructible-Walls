using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using System;
using System.Collections.Generic;
using UnityEngine.Serialization;
#if UNITY_EDITOR
using Unity.Animation.Hybrid;
#endif

namespace Junk.Core.Animation
{
    
#if UNITY_EDITOR
    public class Spawner : MonoBehaviour, IDeclareReferencedPrefabs, IConvertGameObjectToEntity
    {
        public                                                                                      GameObject           RigPrefab;
        [FormerlySerializedAs("graphAuthoringPrefab")] [FormerlySerializedAs("GraphPrefab")] public SampleGraphAuthoring sampleGraphAuthoringPrefab;

        public int CountX = 100;
        public int CountY = 100;

        public void DeclareReferencedPrefabs(List<GameObject> referencedPrefabs)
        {
            referencedPrefabs.Add(RigPrefab);
        }

        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            var rigPrefab = conversionSystem.TryGetPrimaryEntity(RigPrefab);

            if (rigPrefab == Entity.Null)
                throw new Exception($"Something went wrong while creating an Entity for the rig prefab: {RigPrefab.name}");

            if (sampleGraphAuthoringPrefab != null)
            {
                var rigComponent = RigPrefab.GetComponent<RigComponent>();
                sampleGraphAuthoringPrefab.PreProcessRig(rigComponent);
                sampleGraphAuthoringPrefab.ConvertGraphData(rigPrefab, dstManager, conversionSystem);
            }

            dstManager.AddComponentData(entity, new RigSpawner
            {
                RigPrefab = rigPrefab,
                CountX    = CountX,
                CountY    = CountY,
            });
        }
    }
#endif

    public struct RigSpawner : IComponentData
    {
        public Entity RigPrefab;
        public int    CountX;
        public int    CountY;
    }

    [UpdateInGroup(typeof(PresentationSystemGroup))]
    public class RigSpawnerSystem : SystemBase
    {
        //AnimationInputBase m_Input;

        //public void RegisterInput(AnimationInputBase input)
        //{
            //m_Input = input;
        //}

        protected override void OnUpdate()
        {
            CompleteDependency();

            //if (Keyboard.current.spaceKey.isPressed)
            //{
                Entities
                .WithoutBurst()
                .WithStructuralChanges()
                .ForEach((Entity e, ref RigSpawner spawner) =>
                {

                    //if (m_Input != null)
                    //m_Input.RegisterEntity(rigInstance);
                    
                    for (var x = 0; x < spawner.CountX; x++)
                    {
                        for (var y = 0; y < spawner.CountY; ++y)
                        {
                            var rigInstance = EntityManager.Instantiate(spawner.RigPrefab);
                            var translation = new float3(x * 1.3F, 0, y * 1.3F);
                            //var translation = new float3(1,0, 1);
                            EntityManager.SetComponentData(rigInstance, new Translation {Value = translation});
                            var npc = EntityManager.GetComponentData<Npc>(rigInstance);
                            npc.Random = new Unity.Mathematics.Random((uint)UnityEngine.Random.Range(0, 10000));
                            EntityManager.SetComponentData(rigInstance,npc);
                        }
                    }

                    EntityManager.DestroyEntity(e);
                }).Run();
                
            //}
            
        }
    }
}