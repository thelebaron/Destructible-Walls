using Unity.Animation;
using Unity.Entities;
using UnityEngine;
using Unity.Animation.Hybrid;
using UnityEditor.Animations;

namespace Junk.Core.Animation
{
    public class SampleGraphAuthoring : MonoBehaviour, IConvertGameObjectToEntity
    {
        public AnimationClip SingleClip;

        public AnimationClip IdleClip;
        public AnimationClip WalkClip;
        public AnimationClip RunClip;
        public BlendTree     LocomotionBlendTree;

        public string MotionName;
        public bool   Bake;
        public float  SampleRate = 60.0f;
        public bool   LoopValues;
        public bool   BankPivot;

        private StringHash m_MotionId;

        public bool debugAttached;

        public void PreProcessRig(RigComponent data)
        {
            var rig = data;

            foreach (var t in rig.Bones)
            {
                if (MotionName == t.name)
                {
                    m_MotionId = RigGenerator.ComputeRelativePath(t, rig.transform);
                }
            }
        }

        public void ConvertGraphData(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            var idleClip = IdleClip.ToDenseClip();
            var walkClip = WalkClip.ToDenseClip();
            var runClip  = RunClip.ToDenseClip();
            var singleClip = SingleClip.ToDenseClip();
            
            var clipConfiguration = new ClipConfiguration {Mask = ClipConfigurationMask.LoopTime | ClipConfigurationMask.CycleRootMotion | ClipConfigurationMask.DeltaRootMotion};

            clipConfiguration.Mask |= LoopValues ? ClipConfigurationMask.LoopValues : 0;
            clipConfiguration.Mask |= BankPivot ? ClipConfigurationMask.BankPivot : 0;

            clipConfiguration.MotionID = m_MotionId;

            var graphSetup = new NpcAnimGraphSetup
            {
                SingleClip = singleClip,
                IdleClip   = idleClip,
                WalkClip   = walkClip,
                RunClip    = runClip
            };

            var rigDefinition = dstManager.GetComponentData<Rig>(entity);

            if (Bake)
            {
                graphSetup.IdleClip   = UberClipNode.Bake(rigDefinition.Value, idleClip, clipConfiguration, SampleRate);
                graphSetup.WalkClip   = UberClipNode.Bake(rigDefinition.Value, walkClip, clipConfiguration, SampleRate);
                graphSetup.RunClip    = UberClipNode.Bake(rigDefinition.Value, runClip, clipConfiguration, SampleRate);
                graphSetup.SingleClip = UberClipNode.Bake(rigDefinition.Value, singleClip, clipConfiguration, SampleRate);

                clipConfiguration.Mask     = ClipConfigurationMask.NormalizedTime | ClipConfigurationMask.LoopTime | ClipConfigurationMask.RootMotionFromVelocity;
                clipConfiguration.MotionID = 0;
            }
            else
            {
                clipConfiguration.Mask |= ClipConfigurationMask.NormalizedTime;
            }

            graphSetup.Configuration = clipConfiguration;
            dstManager.AddComponentData(entity, graphSetup);
            dstManager.AddComponent<ProcessDefaultAnimationGraph.AnimatedRootMotion>(entity);
            dstManager.AddComponent<DisableRootTransformReadWriteTag>(entity);
            dstManager.AddComponent<DeltaTime>(entity);
        }

        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            if (debugAttached)
            {
                var rigComponent = GetComponent<RigComponent>();
                PreProcessRig(rigComponent);
                ConvertGraphData(entity, dstManager, conversionSystem);
            }
        }
    }
}