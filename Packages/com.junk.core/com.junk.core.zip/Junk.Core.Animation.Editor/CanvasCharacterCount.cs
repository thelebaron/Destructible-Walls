using Junk.Core.Animation;
using Unity.Collections;
using Unity.Entities;
using UnityEngine;
using UnityEngine.UI;

namespace CyberJunk.Characters.Animation
{
    public class CanvasCharacterCount : MonoBehaviour
    {
        public Text        textComponent;
        public EntityQuery query;
        private void Start()
        {
            query = World.DefaultGameObjectInjectionWorld.EntityManager.CreateEntityQuery(typeof(SampleNpcGraphInputs));
        
            var em = World.DefaultGameObjectInjectionWorld.EntityManager;
            query.ToEntityArray(Allocator.Temp);
            var count = query.CalculateEntityCount();


            textComponent.text = "Character count is = " + count.ToString();
        }

        void Update()
        {
            if (Input.GetKeyUp(KeyCode.Space))
            {
                var em = World.DefaultGameObjectInjectionWorld.EntityManager;
                query.ToEntityArray(Allocator.Temp);
                var count = query.CalculateEntityCount();


                textComponent.text = "Character count is = " + count.ToString();
            }
        }
    }

}
